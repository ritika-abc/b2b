
<!doctype html>
<html lang="en">

	<head>
		<meta charset="utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta name="generator" content="d3d3LmV4cG9ydGVyc2luZGlhLmNvbQ==">		<link rel="icon" href="https://www.exportersindia.com/favicon.ico" type="image/x-icon" />

				<link rel="preconnect" href="https://static.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://js.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://css.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://dyimg.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://img1.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://img2.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://img3.exportersindia.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://www.google-analytics.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://pagead2.googlesyndication.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://www.googletagmanager.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://connect.facebook.net" crossorigin="anonymous">
		<link rel="preconnect" href="https://googleads.g.doubleclick.net" crossorigin="anonymous">
		<link rel="preconnect" href="https://static.zohocdn.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://www.googleadservices.com" crossorigin="anonymous">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://static.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://js.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://css.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://dyimg.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://img1.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://img2.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://img3.exportersindia.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://www.google-analytics.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://pagead2.googlesyndication.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://googleads.g.doubleclick.net" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://www.googletagmanager.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://connect.facebook.net" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://static.zohocdn.com" crossorigin="anonymous">
		<link rel="dns-prefetch" href="https://www.googleadservices.com" crossorigin="anonymous">
			<title>
			</title>
	<meta name="description" content="">
	<meta name="keywords" content="">
			<META NAME="ROBOTS" CONTENT="noindex, nofollow">
		
		<link rel="preload" href="https://static.exportersindia.com/css/header-footer.css?v=5" as="style">
<link rel="stylesheet" href="https://static.exportersindia.com/css/header-footer.css?v=5">
		<link rel="preload" href="https://css.exportersindia.com/css/L1_L2_L3.css?v=1714287860" as="style">
<link href="https://css.exportersindia.com/css/L1_L2_L3.css?v=1714287860" rel="stylesheet" type="text/css">

				<!-- Global site tag (gtag.js) - Google Ads: 980117963 -->
		<link rel="preload" as="script" href="https://www.googletagmanager.com/gtag/js?id=AW-980117963"
			onload="var script = document.createElement('script'); script.src = this.href; document.head.appendChild(script);">
		<script>
			window.dataLayer = window.dataLayer || [];
			function gtag() { dataLayer.push(arguments); }
			gtag('js', new Date());
			gtag('config', 'AW-980117963', { 'allow_enhanced_conversions': true });
		</script>

		<!-- Google Tag Manager -->
		<script>(function (w, d, s, l, i) {
				w[l] = w[l] || []; w[l].push({
					'gtm.start':
						new Date().getTime(), event: 'gtm.js'
				}); var f = d.getElementsByTagName(s)[0],
					j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''; j.async = true; j.src =
						'https://www.googletagmanager.com/gtm.js?id=' + i + dl; f.parentNode.insertBefore(j, f);
			})(window, document, 'script', 'dataLayer', 'GTM-N77LX7D');</script>
		<!-- End Google Tag Manager -->
		
	</head>
	
				<body >
					
										<!-- Google Tag Manager (noscript) -->
					<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N77LX7D" height="0" width="0"
							style="display:none;visibility:hidden" loading="lazy"></iframe></noscript>
					<!-- End Google Tag Manager (noscript) -->
										<!--
<aside class="no-js" style="padding-bottom:50px;position:absolute;bottom:0px;">
<div class="pf w100 db darkbgerror white darkbg gbiwb tac pt5px pb5px small bdrb bdr666 b" style="z-index:999;">
<p>JavaScript is disabled in your browser. Enable JavaScript for full functionality of this site.</p>
<p>To know how to enable JavaScript in your web browser <a href="http://www.enable-javascript.com/" class="yellow" target="_blank" rel="nofollow">click here</a>.</p>
</div>
</aside> -->
					
							<header class="eih-header">
								<div class="eih_top_bg">
									<div class="fw">
										<div class="eih-top">

																																	<div class="eih-top-left">
												<ul>
																										<li>Welcome User! </li>
													<li><a href="javascript:void(0);" class="ip_login"
															title="Login to Exportersindia"><img src="https://static.exportersindia.com/ei_images/svg_icon/sign-in.svg" alt="Sign In" width="13" height="13" decoding="async" fetchpriority="low"> <span>Sign In</span></a></li>
													<li><a href="https://www.exportersindia.com/register-business-online?joinfree=header"
															title="Join Exportersindia Free" class="join_now_click_cls"
															attr-source-id="1"><img src="https://static.exportersindia.com/ei_images/svg_icon/join-free.svg" alt="Join Free" width="14" height="14" decoding="async" fetchpriority="low">
															<span>Join Free</span></a></li>
																										

												</ul>
											</div>
																						<div class="call_us_no">
												<a href="tel:+91-9953717914"><span>Sales
														:</span>
													+91-9953717914												</a>
												<span style="color:#ccc;padding:0px 10px">|</span>
												<a href="tel:+91-9700318318"><span>Support
														:</span>
													+91-9700318318												</a>
											</div>
											

											<div class="eih-top-right">
												<ul>
													<li> <a href="javascript:void(0);"> <img
																src="https://static.exportersindia.com/ei_images/svg_icon/icon_for_buyer.svg"
																alt="" width="19" height="19" decoding="async"
																fetchpriority="low"> For Buyer <i
																class="fa fa-angle-down"></i> </a>
														<ul class="top_sub_menu">
															<li><a
																	href="https://www.exportersindia.com/post-buy-requirement.php">Post
																	Buy Requirement</a></li>
															<li><a href="https://www.exportersindia.com/industry/">Browse
																	Suppliers</a></li>
															<li><a href="https://www.exportersindia.com/manufacturers/">Manufacturers
																	Directory</a></li>
															<li><a
																	href="https://www.exportersindia.com/b2b-marketplace.htm">Country
																	Suppliers</a></li>
															<li><a
																	href="https://www.exportersindia.com/help/buyer_faq.htm">Buyer
																	FAQ</a></li>
														</ul>
													</li>
													<li> <a href="javascript:void(0);"> <img
																src="https://static.exportersindia.com/ei_images/svg_icon/icon_for_seller.svg"
																alt="" width="19" height="19"
																decoding="async" fetchpriority="low"> For Seller <i
																class="fa fa-angle-down"></i> </a>
														<ul class="top_sub_menu">
																														<li><a href="https://www.exportersindia.com/register-business-online?joinfree=sellurprdtshead"
																	class="join_now_click_cls" attr-source-id="2">Sell
																	Your Product</a></li>
																														<li><a href="https://www.exportersindia.com/buyers/">Latest
																	Buyleads </a></li>
															<li><a
																	href="https://www.exportersindia.com/help/seller_faq.htm">Seller
																	FAQ </a></li>

														</ul>
													</li>
													<li> <a href="javascript:void(0);"><img
																src="https://static.exportersindia.com/ei_images/svg_icon/icon_help.svg"
																alt="" width="19" height="19" decoding="async"
																fetchpriority="low"> Help <i
																class="fa fa-angle-down"></i> </a>
														<ul class="top_sub_menu">
																														<li><a href="https://www.exportersindia.com/feedback.htm">Send Feedback</a></li>
															<li><a href="/complaint.htm">Send
																	Complaint</a></li>
															<li><a href="https://www.exportersindia.com/advertise/">Advertise
																	with us</a></li>
															<li><a
																	href="https://members.exportersindia.com/contact-us.htm">Contact
																	Us</a></li>
																														<li class="menu_help">
																<div class="cal_icon"><img
																		src="https://static.exportersindia.com/ei_images/svg_icon/call_us.svg"
																		width="19" height="19" alt="call us"
																		decoding="async" fetchpriority="low"></div>
																<div class="help_num">
																	<a
																		href="tel:+91-9953717914"><span>Sales</span>
																		<span>:</span>
																		+91-9953717914																	</a>
																	<a
																		href="tel:+91-9700318318"><span>Support</span>
																		<span>:</span>
																		+91-9700318318																	</a>
																</div>
															</li>
															
														</ul>
													</li>
												</ul>
											</div>
											

										</div>
									</div>
								</div>
								<div  >
	<div class="fw">

		<div class="ein-header"> 
					<a href="https://www.exportersindia.com/" class="ei-logo">Exporters India</a>
					
		
							<form id="search-form" action="https://www.exportersindia.com/search.php" method="GET" onsubmit="return catg_search_new(this);" autocomplete="off">
								<div class="eih-searh">
									<div class="eih-dropdown">
						<div class="hst"> <span class="hst-txt">Products / Services</span> <i class="fa fa-angle-down"></i> </div>
						<ul class="hst-list">
						<li data-jq-value="Products / Services" id="Prod">Products / Services</li>
						<li data-jq-value="Companies" id="comp">Companies</li>
						<li data-jq-value="Buy Leads" id="buy_offers">Buy Leads</li>
						</ul>
					</div>
					<input type="hidden" value="prod" id="search-select-hidden" name="srch_catg_ty" />
										<div class="eih-input">
					   						
												<div class="speech">
							<input type="text" name="term" id="transcript" placeholder="Enter product / service to search" value="" autocomplete="off" maxlength="50"/>				
							<div aria-label="Search by voice" role="button" tabindex="0" id="VoiceSearch_DG"><svg focusable="false" viewBox="0 0 24 24" width="25" height="25" xmlns="http://www.w3.org/2000/svg"><path fill="#4285f4" d="m12 15c1.66 0 3-1.31 3-2.97v-7.02c0-1.66-1.34-3.01-3-3.01s-3 1.34-3 3.01v7.02c0 1.66 1.34 2.97 3 2.97z"></path><path fill="#34a853" d="m11 18.08h2v3.92h-2z"></path><path fill="#fbbc05" d="m7.05 16.87c-1.27-1.33-2.05-2.83-2.05-4.87h2c0 1.45 0.56 2.42 1.47 3.38v0.32l-1.15 1.18z"></path><path fill="#ea4335" d="m12 16.93a4.97 5.25 0 0 1 -3.54 -1.55l-1.41 1.49c1.26 1.34 3.02 2.13 4.95 2.13 3.87 0 6.99-2.92 6.99-7h-1.99c0 2.92-2.24 4.93-5 4.93z"></path></svg></div>
						</div>
						<ul class="eih-input-dropdown" id="newKeywordList">
						  
						</ul>
							
					</div>
					<div class="eih-search-btn">
														<input type="hidden" value="IN" name="cont" id="search_country_id" />
														<input type="hidden" value="N" name="ss_status" id="ss_status"/>
						<button type="submit" onclick="_gaq.push(['_trackEvent', 'button', 'SearchClicked', 'https://www.exportersindia.com/search.php', 0, 'true']);">Search</button>
					</div>
				</div>
			</form>
			
			
			<a href="https://www.exportersindia.com/post-buy-requirement.php" class="eih-pyr" onclick="_gaq.push(['_trackEvent', 'button', 'PostREQClicked', 'https://www.exportersindia.com/post-buy-requirement.php', 0, 'true']);">Post Buy Requirement</a>
		</div>
	</div>
</div>
							</header>
							<div class="eih-searh-overlay"></div>

							<!-- <div class="header_h"></div>-->
								<br>
	
	<section class="fo fw">
	<article class="fl w70">
	
	<ul class="gray fo uo ac-fl ac-mr5px">
	<li>Products</li>
	<li><b class="ffv vam">&raquo;</b> <b class="hig xlarge"></b></li>
	<li>0 Result(s) Found</li>
	<li class="ml20px mr20px">|</li>
	<li>Country : <b class="hig xlarge ml5px">India</b></li>
	</ul>
	
	<br>
	
	<div class="p15px bdr tac xlarge lightbgwarning lightbdrwarning graydark lh15em">
	<img src="https://static.exportersindia.com/ei_images/icon_error4error_pg.gif" class="vam">Sorry! No results found for "<b class="dif bn"></b>" in "<b class="dif bn">India</b>" as per your search criteria. 
	<br>Please try with other search criteria or change the country to get more results. 
	</div>
	
	<br /><br /> 
	
	<form id="search-form" action="https://www.exportersindia.com/search.php" method="GET" onsubmit="return catg_search_new(this);">
	<div class="bgf7f7f7 gbiwb bdr p10px15px">
	<p class="xxxlarge b gray pl2px mb10px">Refine Search</p>
	<ul class="fo ml2px ac-fl ac-ml12px fc-ml0">
	
	<li>
	<input type="text" placeholder="Enter your Keyword" class="w200px bdr p7px input bgfff search_prod_serv_auto" autocomplete="off" maxlength="50" name="term" value="">
	</li>
	
	<li>
	<select class="w150px bdr p7px input bgfff" name="cont">
	<option value="">-----All Countries-----</option>
	<option value="AF" >Afghanistan</option><option value="AL" >Albania</option><option value="DZ" >Algeria</option><option value="AS" >American Samoa</option><option value="AD" >Andorra</option><option value="AO" >Angola</option><option value="AI" >Anguilla</option><option value="AQ" >Antarctica</option><option value="AG" >Antigua and Barbuda</option><option value="AR" >Argentina</option><option value="AM" >Armenia</option><option value="AW" >Aruba</option><option value="AU" >Australia</option><option value="AT" >Austria</option><option value="AZ" >Azerbaijan</option><option value="BS" >Bahamas</option><option value="BH" >Bahrain</option><option value="BD" >Bangladesh</option><option value="BB" >Barbados</option><option value="BY" >Belarus</option><option value="BE" >Belgium</option><option value="BZ" >Belize</option><option value="BJ" >Benin</option><option value="BM" >Bermuda</option><option value="BT" >Bhutan</option><option value="BO" >Bolivia</option><option value="BA" >Bosnia and Herzegowina</option><option value="BW" >Botswana</option><option value="BV" >Bouvet Island</option><option value="BR" >Brazil</option><option value="IO" >British Indian Ocean Territory</option><option value="BN" >Brunei Darussalam</option><option value="BG" >Bulgaria</option><option value="BF" >Burkina Faso</option><option value="BI" >Burundi</option><option value="KH" >Cambodia</option><option value="CM" >Cameroon</option><option value="CA" >Canada</option><option value="CV" >Cape Verde</option><option value="KY" >Cayman Islands</option><option value="CF" >Central African Republic</option><option value="TD" >Chad</option><option value="CL" >Chile</option><option value="CN" >China</option><option value="CX" >Christmas Island</option><option value="CC" >Cocos (Keeling) Islands</option><option value="CO" >Colombia</option><option value="KM" >Comoros</option><option value="CG" >Congo</option><option value="CK" >Cook Islands</option><option value="CR" >Costa Rica</option><option value="CI" >Cote D'Ivoire</option><option value="HR" >Croatia</option><option value="CY" >Cyprus</option><option value="CZ" >Czech Republic</option><option value="DK" >Denmark</option><option value="DJ" >Djibouti</option><option value="DM" >Dominica</option><option value="DO" >Dominican Republic</option><option value="TP" >East Timor</option><option value="EC" >Ecuador</option><option value="EG" >Egypt</option><option value="SV" >El Salvador</option><option value="GQ" >Equatorial Guinea</option><option value="ER" >Eritrea</option><option value="EE" >Estonia</option><option value="ET" >Ethiopia</option><option value="FK" >Falkland Islands (Malvinas)</option><option value="FO" >Faroe Islands</option><option value="FJ" >Fiji</option><option value="FI" >Finland</option><option value="FR" >France</option><option value="FX" >France, Metropolitan</option><option value="GF" >French Guiana</option><option value="PF" >French Polynesia</option><option value="TF" >French Southern Territories</option><option value="GA" >Gabon</option><option value="GM" >Gambia</option><option value="GE" >Georgia</option><option value="DE" >Germany</option><option value="GH" >Ghana</option><option value="GI" >Gibraltar</option><option value="GR" >Greece</option><option value="GL" >Greenland</option><option value="GD" >Grenada</option><option value="GP" >Guadeloupe</option><option value="GU" >Guam</option><option value="GT" >Guatemala</option><option value="GN" >Guinea</option><option value="GW" >Guinea-bissau</option><option value="GY" >Guyana</option><option value="HT" >Haiti</option><option value="HM" >Heard and Mc Donald Islands</option><option value="HN" >Honduras</option><option value="HK" >Hong Kong</option><option value="HU" >Hungary</option><option value="IS" >Iceland</option><option value="IN" selected>India</option><option value="ID" >Indonesia</option><option value="IQ" >Iraq</option><option value="IE" >Ireland</option><option value="IL" >Israel</option><option value="IT" >Italy</option><option value="JM" >Jamaica</option><option value="JP" >Japan</option><option value="JO" >Jordan</option><option value="KZ" >Kazakhstan</option><option value="KE" >Kenya</option><option value="KI" >Kiribati</option><option value="KW" >Kuwait</option><option value="KG" >Kyrgyzstan</option><option value="LA" >Lao People's Democratic Republic</option><option value="LV" >Latvia</option><option value="LB" >Lebanon</option><option value="LS" >Lesotho</option><option value="LR" >Liberia</option><option value="LY" >Libya</option><option value="LI" >Liechtenstein</option><option value="LT" >Lithuania</option><option value="LU" >Luxembourg</option><option value="MO" >Macau</option><option value="MK" >Macedonia, The Former Yugoslav Republic of</option><option value="MG" >Madagascar</option><option value="MW" >Malawi</option><option value="MY" >Malaysia</option><option value="MV" >Maldives</option><option value="ML" >Mali</option><option value="MT" >Malta</option><option value="MH" >Marshall Islands</option><option value="MQ" >Martinique</option><option value="MR" >Mauritania</option><option value="MU" >Mauritius</option><option value="YT" >Mayotte</option><option value="MX" >Mexico</option><option value="FM" >Micronesia, Federated States of</option><option value="MD" >Moldova, Republic of</option><option value="MC" >Monaco</option><option value="MN" >Mongolia</option><option value="ME" >Montenegro</option><option value="MS" >Montserrat</option><option value="MA" >Morocco</option><option value="MZ" >Mozambique</option><option value="MM" >Myanmar</option><option value="NA" >Namibia</option><option value="NR" >Nauru</option><option value="NP" >Nepal</option><option value="NL" >Netherlands</option><option value="AN" >Netherlands Antilles</option><option value="NC" >New Caledonia</option><option value="NZ" >New Zealand</option><option value="NI" >Nicaragua</option><option value="NE" >Niger</option><option value="NG" >Nigeria</option><option value="NU" >Niue</option><option value="NF" >Norfolk Island</option><option value="MP" >Northern Mariana Islands</option><option value="NO" >Norway</option><option value="OM" >Oman</option><option value="PK" >Pakistan</option><option value="PW" >Palau</option><option value="PS" >Palestine</option><option value="PA" >Panama</option><option value="PG" >Papua New Guinea</option><option value="PY" >Paraguay</option><option value="PE" >Peru</option><option value="PH" >Philippines</option><option value="PN" >Pitcairn</option><option value="PL" >Poland</option><option value="PT" >Portugal</option><option value="PR" >Puerto Rico</option><option value="QA" >Qatar</option><option value="RE" >Reunion</option><option value="RO" >Romania</option><option value="RU" >Russian Federation</option><option value="RW" >Rwanda</option><option value="KN" >Saint Kitts and Nevis</option><option value="LC" >Saint Lucia</option><option value="VC" >Saint Vincent and the Grenadines</option><option value="WS" >Samoa</option><option value="SM" >San Marino</option><option value="ST" >Sao Tome and Principe</option><option value="SA" >Saudi Arabia</option><option value="SN" >Senegal</option><option value="RS" >Serbia</option><option value="SC" >Seychelles</option><option value="SL" >Sierra Leone</option><option value="SG" >Singapore</option><option value="SK" >Slovakia (Slovak Republic)</option><option value="SI" >Slovenia</option><option value="SB" >Solomon Islands</option><option value="SO" >Somalia</option><option value="ZA" >South Africa</option><option value="GS" >South Georgia and the South Sandwich Islands</option><option value="KR" >South Korea</option><option value="SS" >South Sudan</option><option value="ES" >Spain</option><option value="LK" >Sri Lanka</option><option value="SH" >St. Helena</option><option value="PM" >St. Pierre and Miquelon</option><option value="SD" >Sudan</option><option value="SR" >Suriname</option><option value="SJ" >Svalbard and Jan Mayen Islands</option><option value="SZ" >Swaziland</option><option value="SE" >Sweden</option><option value="CH" >Switzerland</option><option value="TW" >Taiwan</option><option value="TJ" >Tajikistan</option><option value="TZ" >Tanzania, United Republic of</option><option value="TH" >Thailand</option><option value="TG" >Togo</option><option value="TK" >Tokelau</option><option value="TO" >Tonga</option><option value="TT" >Trinidad and Tobago</option><option value="TN" >Tunisia</option><option value="TR" >Turkey</option><option value="TM" >Turkmenistan</option><option value="TC" >Turks and Caicos Islands</option><option value="TV" >Tuvalu</option><option value="UG" >Uganda</option><option value="UA" >Ukraine</option><option value="AE" >United Arab Emirates</option><option value="UK" >United Kingdom</option><option value="US" >United States</option><option value="UM" >United States Minor Outlying Islands</option><option value="UY" >Uruguay</option><option value="UZ" >Uzbekistan</option><option value="VU" >Vanuatu</option><option value="VA" >Vatican City State (Holy See)</option><option value="VE" >Venezuela</option><option value="VN" >Vietnam</option><option value="VG" >Virgin Islands (British)</option><option value="VI" >Virgin Islands (U.S.)</option><option value="WF" >Wallis and Futuna Islands</option><option value="EH" >Western Sahara</option><option value="YE" >Yemen</option><option value="YU" >Yugoslavia</option><option value="ZR" >Zaire</option><option value="ZM" >Zambia</option><option value="ZW" >Zimbabwe</option>	</select>
	</li>
	
	<li>
	<select class="w170px bdr p7px input bgfff" value="" name="srch_catg_ty">
	<option value="prod" >Products / Services</option>
	<option value="comp" >Companies</option>
	<option value="buy_offers" >Buy Leads</option>
	</select>
	</li>
	
	<li><button type="submit" class="bdr p7px15px b white input darkbg1 darkbdr1">Search</button></li>
	
	</ul>
	</div>
	</form>
	
	<br>  
	
	<p class="tac mt10px xxlarge b">OR</p>

	<div class="p20px"> 
		<style>
	#subject_span_suggestion_left .ui-autocomplete{max-height:200px;overflow-y:auto;}
	</style>
	<div class="br5px p3px post_requirement_form_li" style="background-color:#27a97d;">
	<div class="p10px b large tac">
	<p class="white mb5px">To Get Instant Response</p>
	<p class="xxxlarge yellow">Post Your Requirement</p>
	</div>
	
	<div class="bgfff br3px p10px pt15px">
		<p class="ac red" id="show_inq_error_msg_right_side_form"></p>

	<form action="" method="post" class="inputs-error-border" id="right_side_post_requirement_form" name="right_side_post_requirement_form" onsubmit="return supplier_classified_post_req_form_v2(this, 'right_side_post_requirement_form');">
	<input type="hidden" name="bydefault_catg_type"  value="2" class="bydefault_catg_type">
	<ul class="ac-mb10px lc-mb0">
	
	<li class="pr mb10px">
	
	<p class="dul b mb2px">Products / Services Name : </p>
	<input type="text" name="subject" data-ph-hindi="true" class="input p10px bsbb w100 search_prod_serv_auto_company_right_frm" id="subject" autocomplete="off" maxlength="50" data-id='0' placeholder="Products / Services you are looking for">
	<span id="subject_span_suggestion_right" style="position:absolute; left:0;top:100%;z-index:2;"></span>
	</li>
	
	<li class="fo cl_post_req_frm_qu order_quantity_comp_right" style="display:block">
	
	<ul class="fo ac-fl ac-bsbb ac-mb0">
	<li class="w30">
	<label class="db gray mb3px">Quantity</label>
	<input type="text" name="estimate_quantity" id="estimate_quantity" onkeypress="return isdecimalKey(event);" maxlength="20" placeholder="" class="input p10px bsbb w100 comm_df_val" autocomplete="off">
	</li>
	<li class="pr zi1 w70">
	<label class="db gray mb3px">&nbsp;</label>
	<input type="hidden" name="quantity_unit" value="Other">
	<input type="text" name="quantity_unit_txt_fld" id="quantity_unit_txt_fld" placeholder="Unit of Measurement" class="input_fild input p10px bsbb w100 pa zi10 quantity_unit_class comm_df_val" onkeyup="show_quantity_suggestion('quantity_unit_txt_fld_pop');" maxlength="30">
	<span id="quantity_unit_txt_fld_pop"></span>
		</li>
	</ul>
	</li>
	</ul>
		<ul class="ac-mb10px lc-mb0 cl_post_req_frm_desc_comp_right" style="display:none">
		<li class="fo cl_post_req_frm_desc">
		<label class="db gray mb3px">Describe your Requirement</label>
		<textarea class="input p10px bsbb w100 empty_txt_cls comm_df_val" placeholder="Enter Additional details about your requirement..." name="detail_req" maxlength="250"></textarea>
		</li> 
	</ul> 
	<ul class="mt10px ac-mb10px lc-mb0 login_fild ">
		<li>
		<label class="db gray mb3px">Mobile Number</label>
		<input type="hidden" name="country_code" id="country_code" value="IN^91">	
		<input type="tel" name="mobile_phone" id="mobile_phone" onkeypress="return isNumberKey(event);" maxlength="10" placeholder="Mobile No." class="mobile_phone">
		</li> 
		
		<li class="div_email " id="div_email_right_side_post_requirement_form">
		<label class="db gray mb3px">Email</label>
		<input type="text" name="user_name" id="user_name" class="input p10px bsbb w100" placeholder="Enter your Email ID"  >
		</li>
	</ul>
			<input type="hidden" name="lgn_member_status" id="lgn_member_status" value="3">
			<div class="mt5px">
	<button type="submit" name="sendNewSms" id="" class="mt10px ts0 darkbg3 p7px white bdr ffp w100 bsbb xxlarge  tac">Submit</button>
	</div>
	
	
	<input type="hidden" name="inquiry_from_page_url" value="http://www.exportersindia.com/">
	<input type="hidden" name="mem_url" id="mem_url" value="https://members.exportersindia.com/">
	<input type="hidden" name="inq_source" value="desktop_right_side_post_req">
	<input type="hidden" name="submit_action" id="submit_action" value="post_buy_lead_form"/>
	
	<input type="hidden" name="action_type" id="action_type" value="new_post_req_form">
	<input type="hidden" name="preference" id="prs1" value="Anywhere in India">
	<input type="hidden" name="product_type"  value="2" class="product_type">
	
	</form>
	</div>
	</div>
	<script src="https://static.exportersindia.com/js/latest.js/jquery.js"></script>
	<script src="https://static.exportersindia.com/js/root-js/post_req_supplier.js" type="text/javascript"></script>

	<script>
	function show_quantity_suggestion (append_id) {
		
				$(document).ready(function() {
			var availableCityTags = ["Pieces", "Tons", "Units", "Kilogram", "Sets", "Meter", "Boxes", "Metric Tons", "Square Feet", "Pairs", "Bags", "Rolls", "Bottles", "Litres", "Packets", "Sheets", "Foot", "Dozens", "Cartons", "Packs", "Reams", "Grams", "Ounce", "Pound", "20' Container", "40' Container", "Gallon", "Barrel", "Bushel", "Kilometer", "Square Meters", "Hectare", "Short Ton", "Long Ton", "Number"];
			$(".quantity_unit_class").keypress(function(){
				
				$(".quantity_unit_class").autocomplete({
				
					minLength: 1,
					appendTo: "#"+append_id,
					source: function( request, response ) {
			          var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( request.term ), "i" );
			          response( $.grep( availableCityTags, function( item ){
			              return matcher.test( item );
			          }) );
	      			}
				});	
			});
		});
	}
	
	function isdecimalKey(evt)
	{
	  var charCode = (evt.which) ? evt.which : evt.keyCode;
	  if (charCode != 46 && charCode > 31 
		&& (charCode < 48 || charCode > 57))
		 return false;

	  return true;
	}
	
	$(function(){
		if($('#default_cont_id').val() != 'IN'){
			$('#right_side_post_requirement_form .div_email ').show();
		}
		else {
		
			$('#right_side_post_requirement_form .div_email ').hide();
		}
	});
	</script>
		</div>
	
	</article>
	
	<aside class="bdrl dashed w28 fr">

	<div class="bdr bgfff">
	<p class="p7px10px xxxlarge bdrb lightbg1 ffrc"><b class="plusMinus act"></b> Browse By Categories</p>
	<div class="showHide_rp">
		<ul class="m10px ac-mb5px hig-anchors uo ac-fo">	 
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/agriculture.htm">Agriculture</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/fashion-apparel.htm">Apparel & Fashion</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/automobile.htm">Automotive & Auto Parts</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/ayurvedic-herbal.htm">Ayurvedic & Herbal Products</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/indian-services/">Business Services</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/chemicals.htm">Chemicals</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/computers-internet.htm">Computers & PC Hardware</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/realestate-construction.htm">Construction & Real Estate</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/consumer-electronics.htm">Consumer Electronics</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/electronics-electrical.htm">Electronics & Electrical Components</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/indian-services/financial.htm">Financial Services</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/furniture.htm">Furniture Manufacturers</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/food-beverages.htm">Food Product & Beverages</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/gifts-crafts.htm">Handicrafts & Gifts</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/health-beauty.htm">Health & Beauty</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/home-supplies.htm">Home Supplies</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/home-furnishings.htm">Home Furnishings</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/industrial-supply.htm">Industrial Supplies </a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/jeweller.htm">Jewelry</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/machines.htm">Machines & Equipment</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/mineral-metals.htm">Mineral & Metals</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/office-supplies.htm">Office Supplies & Stationery</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/packaging-paper.htm">Paper & Packaging Material</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/textiles.htm">Textiles & Fabrics</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/industry/tools.htm">Tools & Equipment</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/indian-services/transportation.htm">Transportation Services</a></li>
	<li><b class="fa fa-angle-right xxxsmall vam mr5px"></b>
	<a href="https://www.exportersindia.com/indian-services/tours-travels.htm">Tours & Travel</a></li>
	</ul> 
		</div>
	</div> 
	</aside>
	
	</section>	  
    		<section class="fn_sec_inn">
			<div class="fw">
				<div class="fna-sec">
					<ul class="fnav">
													<li>
								<h3 class="fnav-title">Our Services</h3>
								<ul class="fnav-list service-link">
									
									<li><a href="https://www.exportersindia.com/advertise/">Advertise with us</a></li>
									<li><a href="https://www.exportersindia.com/advertise/">Membership Plan</a></li>
									<li><a href="https://www.exportersindia.com/advertise/banner-advertising.html">Banner Advertisement</a></li>
									<li><a href="https://pay-via.exportersindia.com" target="_blank">Pay Via ExportersIndia</a></li>										 
								</ul>
							</li>
													<li>
							<h3 class="fnav-title">Buyers</h3>
							<ul class="fnav-list buyers-link">
								<li><a href="https://www.exportersindia.com/post-buy-requirement.php">Post Your Requirement</a></li>
								<li><a href="https://www.exportersindia.com/industry/">Browse Suppliers</a></li>
								<li><a href="https://www.exportersindia.com/manufacturers/">Manufacturers Directory</a></li>
								<li><a href="https://www.exportersindia.com/b2b-marketplace.htm">Country Suppliers</a></li>
								<li><a href="https://www.exportersindia.com/help/buyer_faq.htm">Buyer FAQ</a></li>
							</ul>
						</li>
						<li>
							<h3 class="fnav-title">Sellers</h3>
								
								<ul class="fnav-list seller-link">
																			<li><a href="https://www.exportersindia.com/register-business-online?joinfree=sellurprdtsfoot" class="join_now_click_cls" attr-source-id="4">Sell Your Product</a></li>
																		<li><a href="https://www.exportersindia.com/buyers/">Latest Buyleads</a></li>
									<li><a href="https://www.exportersindia.com/help/seller_faq.htm">Seller FAQ</a></li>
								</ul>
							    						</li>
						<li>
							<h3 class="fnav-title">Quick Links</h3>
							<ul class="fnav-list q-link">
								<li><a href="https://www.exportersindia.com/about-us.htm">About Us</a></li>
								<li><a href="http://jobs.weblink.in/">Jobs & Careers</a></li>
								<li><a href="https://members.exportersindia.com/contact-us.htm">Contact Us</a></li>
								<li><a href="https://www.exportersindia.com/feedback.htm">Feedback</a></li>
								<li><a href="/complaint.htm">Complaint</a></li>
								<li><a href="https://www.exportersindia.com/testimonials.htm">Testimonials</a></li>
								<li><a href="https://www.exportersindia.com/disclaimer.htm">Disclaimer</a></li>
								<li><a href="https://www.exportersindia.com/sitemap.htm">Sitemap</a></li>
								<li><a href="https://www.exportersindia.com/live-coverage.htm" class="live-coverage"><span>LIVE</span>COVERAGE</a></li>
							</ul>
						</li>
						<li class="f_nav">
							<ul class="app_store">
								<li> 
																	<a href="https://itunes.apple.com/in/app/exportersindia/id827662453?mt=8"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/apple_store_icon.svg" alt="apple app" width="130" height="39"></a>
									<a href="https://play.google.com/store/apps/details?id=com.exportersindia.com&hl=en"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/google_store_icon.svg" alt="android app" width="130" height="39"></a> 
																	</li>
								<li> 
								<p>Connect with us</p>
				                <a href="https://www.facebook.com/exportersindia" title="Follow us on Facebook" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/icon_facebook.svg" alt="" width="30" height="30"></a>
				               <a href="https://twitter.com/exportersindia" title="Follow us on Twitter" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/icon_twitter.svg?v=1" alt="" width="30" height="30"></a>
				               <a href="https://www.linkedin.com/company/exportersindia/" title="Connect Exportersindia on Linkedin" target="_blank"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/icon_linkedin.svg" alt="" width="30" height="30"></a>
				                <a href="https://www.pinterest.com/exportersindia/" title="ExportersIndia on Pinterest" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/icon_pinterest.svg" alt="" width="30" height="30"></a>
				               <a href="https://www.exportersindia.com/blog/" title="B2B Marketplace Guide" target="_blank"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/icon_blog.svg" alt="" width="30" height="30"></a>
				                <a href="https://www.instagram.com/exportersindia/" title="Follow us on Instagram" target="_blank" rel="nofollow"><img loading="lazy" decoding="async" fetchpriority="low" src="https://static.exportersindia.com/ei_images/icon_instagram.svg" alt="" width="30" height="30"></a>
				                
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</section>
		
		<footer class="eih-footer">
			
		<div class="copy_right">
			<div class="fw">
				<div class="eihf">
					<div>Copyright &copy; 1997-2024 <a href="https://www.weblink.in/" target="_blank">Weblink.In Pvt. Ltd.</a> All rights reserved.</div>
					<div> <a href="https://www.exportersindia.com/privacy-policy.htm">Privacy Policy</a> - <a href="https://www.exportersindia.com/terms-conditions.htm">Terms of Use</a> </div>
				</div>
			</div>
		</div>		
		</footer>
		<style>
.member_icon .grid_pa_icon{display:none !important;}
.member_ship_icon .member_icon{display:none !important;}
	.attract_more_buyers_fixer{position:fixed; top:90px; width:250px; background:#fff;}
	</style>
	<div id="listner">
		<div class="close" id="abort_DG"><img src="https://static.exportersindia.com/ei_images/close_icon.svg" width="18" height="18" alt="" decoding="async" fetchpriority="low"></div>
		<div class="voice_popup">
			<div class="output">Waiting for permission</div>
			<div class="text_temp"><div class="temp_dg">To search by voice, go to your browser settings and allow access to microphone</div></div>
			<div class="object">
			<div class="outline pulse"></div> 
			<div class="button"></div>
			<div class="button disable safari_only" id="circlein" aria-label="Search by voice" role="button" tabindex="0">
				<svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" class="mic-icon" viewBox="0 0 1000 1000">
					<path d="M500 683.8c84.6 0 153.1-68.6 153.1-153.1V163.1C653.1 78.6 584.6 10 500 10S346.9 78.6 346.9 163.1v367.5c0 84.6 68.5 153.2 153.1 153.2zm214.4-245v91.9C714.4 649 618.4 745 500 745s-214.4-96-214.4-214.4v-91.9h-61.3v91.9c0 141.9 107.2 258.7 245 273.9v124.2H346.9V990h306.3v-61.3H530.6V804.5c137.8-15.2 245-132.1 245-273.9v-91.9h-61.2z"/>
				</svg>
			</div>
			</div>
			<br>
			<div class="hint_DG dn">Allow microphone access to search with voice</div>
		</div>
	</div>
	<div class="pop_bg" style="display:none"></div>
	<div id="popup_ei"></div>	

<!--inquiry_popop_new_chang-->
<div id="post_req_popup_ei"></div>
<!--inquiry_popop_new_change_end-->

<div id="post_req_popup_ei_thanks"></div>

<div id="login_popup_container"></div>

<input type="hidden" name="base_url" id="base_url" value="https://www.exportersindia.com">
<input type="hidden" name="mem_baseurl" id="mem_baseurl" value="https://members.exportersindia.com">
<input type="hidden" id="allowed_page_popup_form" value="0">

<!-- code for post requirement auto fill if user already loged in ended -->		
<!--used in post req form ajax-->
<input type="hidden" name="default_cont_id" id="default_cont_id" value="">
<input type="hidden" name="default_cont_isd_code" id="default_cont_isd_code" value="">
<!--used in post req form ajax-->
<input type="hidden" id="root_catg_slno" value="0">
	<input type="hidden" name="mem_url" id="mem_url" value="https://members.exportersindia.com">		
	<script  src="https://js.exportersindia.com/js/dynamic_footer_index_js.js"></script>
<script  src="https://js.exportersindia.com/js/new_inquiry_ajax.js"></script>
<script  src="https://js.exportersindia.com/js/jquery.validate.js"></script>
	<script>
	function showMe(box,e_name) {		
		var chboxs = document.getElementsByName(e_name+"[]");
		var vis = "none";
		for(var i=0;i<chboxs.length;i++) { 						
			if(chboxs[i].checked){				
			 vis = "block";
				break;
			}
		}		
		document.getElementById(box).style.display = vis;
	}
	</script>
		
	<script>
	jQuery(document).ready(function(){jQuery('a[rel="inquiryPopup"]').fancybox({width:800,height:500,type:"iframe",transitionIn:"none",transitionOut:"fade",autoScale:!1,scrolling:!0})});
	</script>

		<script defer src="https://js.exportersindia.com/js/latest.js/fancybox/jquery.fancybox.js"></script>
	<script defer  src="https://js.exportersindia.com/js/latest.js/jquery.validate.js"></script>
	<script defer src="https://js.exportersindia.com/js/new_inquiry_ajax.js"></script>
	<script defer src="https://js.exportersindia.com/js/post-req.js"></script>	
	
	<script> <!-- This is used for Post Your Buy Requirement Search page -->
	ValidateRequirementForm('#post-requirement');
	</script>
	<script defer src="https://js.exportersindia.com/js/root-js/login.js?v=1714287860"></script>
<script async src="https://js.exportersindia.com/js/root-js/ei_inq_form_v4.js?v=4"></script>
<script defer src="https://static.exportersindia.com/js/root-js/post_req_supplier_v2.js?time=1714287860"></script>
	<script async="async" src="https://static.exportersindia.com/js/voice-to-text-search.js"></script>	
		<script>
	var telInputSupported = 'input' in document && document.createElement('input').type === 'tel';

    if (telInputSupported) {
		$("input[type=tel]").intlTelInput({
			initialCountry: ''
		});
	}	
	</script>
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
	
  ga('create', 'UA-16625285-3', 'auto');
  ga('send', 'pageview');

</script>  
<script>
(function abc(bannerIdText){
	for(i=1; i<3; i++){
		id=document.getElementById(bannerIdText+i);
		if(id){
			//alert('Showing Banner : ' + bannerIdText + i)
			id.style.display='';	
		}
	}
})('PaidClientBanner')
</script><script>
$(document).ready(function(){	
	$( "#global_search_kword" ).autocomplete({		
		source: "https://www.exportersindia.com/catg_search.php?action=get_main_serch_kword", // data should be in json format	
		appendTo: "#index_global_search",			
		minLength: 3,		
		select: function(event, ui) {			
			$( "#global_search_kword" ).val(ui.item.value);	
					
				$( "#search-form" ).submit();
				    	}
	});	
});
	
var availableUnitTags = [];
$(function(){
	
	if($('.quantity_unit_class').length){
		var ajax_url = 'https://www.exportersindia.com';
		
	    $.ajax({		
			url: ajax_url+"/catg_search.php",	
			type: "POST",
			async: false,
			data: { action:'get_cache_json_unit'},		
			success: function(getdata_data) {		
				var getdata = getdata_data.trim();
				if(getdata){
				
					getdata = jQuery.parseJSON(getdata);
		            $.each(getdata, function(index, value) {
		                availableUnitTags.push(value);
		            });
		            
				}		
			}
		});
		
		$( ".quantity_unit_class" ).autocomplete({
		  source: function( request, response ) {
	        var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( request.term ), "i" );
	          response( $.grep( availableUnitTags, function( item ){
	              return matcher.test( item );
	          }) );
			}
		});
	}
});

$(document).ready(function(){	
	$( "#inq_search_country" ).autocomplete({		
		source: "https://members.exportersindia.com/contact-us.htm?action=getCountryAuto", // data should be in json format		
		minLength: 2,		
		select: function(event, ui) {			
			var country_name = ui.item.value;			
			//var label = ui.item.label;        	
        	get_country_code(country_name);	
    	}
	});
});

function get_country_code(country_name) {	
	$.ajax({			
		  url:"https://members.exportersindia.com/contact-us.htm?action=getCountryCode&term="+country_name, 	  	  
		  success:function(result) {			
	  		var country_result = result.replace(/\s/g,"");	  		
	  		if(country_name=='') {		  		
		  		document.getElementById('invalid_country_id').innerHTML="Please enter country";
		  		document.getElementById('invalid_country_id').style.display="";
			  	$("#inq_search_country").attr("style","border-color:#C00;");
	  		}
	  		else {	  		
		  		if(country_result!='') {			  		
			  		document.getElementById('invalid_country_id').style.display="none";
			  		$("#inq_search_country").attr("style","border-color:none;");
		  		}
		  		else {
			  		
			  		document.getElementById('invalid_country_id').innerHTML="Please enter valid country";
			  		document.getElementById('invalid_country_id').style.display="";
			  		$("#inq_search_country").attr("style","border-color:#C00;");
		  		}
	  		}	  		
	  		common_country_select_func(country_result);
		}
	});		
}
</script>

<script>
!function(i){i(function(){var e=0;setInterval(function(){var s=i("#hp-banner-points li"),d=s.length;++e==d&&(e=0),s.find("i").removeClass("dif").addClass("silver").end().find("p").removeClass("hig").addClass("dul"),i(s[e]).find("i").removeClass("silver").addClass("dif").end().find("p").removeClass("dul").addClass("hig")},1500)})}(jQuery);
</script>
<script>
function setGridView(val) {	
			Set_Cookie( 'gridViewStatus',val, 0, '/', '.exportersindia.com', '');
		}

function getGridView() {	
	var cokkie_arr = document.cookie.split('; ');
	var cookie_res = '';	
	var view_grid_cookie_ststus = "";	
	for(var i=0;i<cokkie_arr.length;i++) {		
		cookie_res = cokkie_arr[i].split('=');		
		if(cookie_res[0]=='gridViewStatus') {			
			view_grid_cookie_ststus = cookie_res[1];			
			break;
		}
	}	
	return view_grid_cookie_ststus;
}

var protocol = window.location.href.indexOf("https://")==0?"https":"http";
var prd_target_loc = protocol+'://'+$(location).attr('hostname')+$(location).attr('pathname');

$(document).ready(function () {
	$("#gridButton").click(function () {
		$("#classified_grid_wrap").removeClass("grid_view").addClass("list_view");
		$(this).addClass("bt_on");
		$("#listButton").removeClass("bt_on");
		setGridView('G');
	});
	$("#listButton").click(function () {
		$("#classified_grid_wrap").removeClass("list_view").addClass("grid_view");
		$(this).addClass("bt_on");
		$("#gridButton").removeClass("bt_on");
		setGridView('L');
	});
	var userChoosenView = getGridView();
	if(userChoosenView=='L') {		
		$('#listButton').trigger('click');
	}
	$(document).on("click", ".nocrowl", function(e) {
		//alert($(this).data('nav'));
		location.href=$(this).data('nav');
	});
	$(document).on("click", ".bizcrowl", function(e) {
		var data_biz_catg = $(this).data('biz');
		//alert(data_biz_catg);
		location.href=prd_target_loc+'?biz_catg='+data_biz_catg;
	});	
	$(document).on("click", ".cont_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		location.href=prd_target_loc+'?cont='+cont_att;		
	});	
	$(document).on("click", ".city_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		var cont_city = $(this).data('city');
		location.href=prd_target_loc+'?cont='+cont_att+'&city='+cont_city;		
	});
	$(document).on("click", ".search_cont_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		var term_att = $(this).data('term');
		location.href=prd_target_loc+'?srch_catg_ty=buy_offers&term='+term_att+'&cont='+cont_att;		
	});
	$(document).on("click", ".state_crowl", function(e) {	
		var cont_att = $(this).data('cont');		
		var cont_state = $(this).data('state');
		var term_att = $(this).data('term');
		location.href=prd_target_loc+'?srch_catg_ty=buy_offers&term='+term_att+'&cont='+cont_att+'&state='+cont_state;		
	});
	$(document).on("click", ".search_city_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		var cont_city = $(this).data('city');
		var cont_state = $(this).data('state');
		var term_att = $(this).data('term');
		location.href=prd_target_loc+'?srch_catg_ty=buy_offers&term='+term_att+'&cont='+cont_att+'&state='+cont_state+'&city='+cont_city;		
	});
});
$(".grid_fl").hover(
  function () {
    $(this).addClass("member_icon");
  },
  function () {
    $(this).removeClass("member_icon");
  }
);
$(".classified").hover(
  function () {
    $(this).addClass("member_ship_icon");
  },
  function () {
    $(this).removeClass("member_ship_icon");
  }
);
</script>
<script>
$(window).scroll(function() {    
	var topPos = $(this).scrollTop();    
	if (topPos > 100) {
		$('.to-top').fadeIn();
	} else {
		$('.to-top').fadeOut();
	}
}); 
$(document).ready(function() {
	$('.hst').on('click', function(e) {
		$('.hst-list').show();
		e.stopPropagation();
	});
	$('.hst-list li').on('click', function(e) {
		//$('.hst-txt').text($(this).text());
		//$('.hst-list').hide();
		$('.hst-txt').text($(this).text());
		var id_val = $(this).attr( "id" );
        $('.hst-list').hide();
		$('#search-select-hidden').val(id_val);
		if(id_val=='comp'){
			$('#transcript').attr("placeholder", "Enter company name to search"); //global_search_kword
		}else{
			$('#transcript').attr("placeholder", "Enter product / service to search"); //global_search_kword
		}
		e.stopPropagation();
	})
	$('html').on('click', function() {
		$('.hst-list').hide();
	})
});
$(".to-top").click(function() {
 $("html, body").animate({ scrollTop: 0 }, "slow");
 return false;
}); 
</script>
<script> 
$(document).ready(function(){$("#psh").click(function(){"password"==$("#password").prop("type")?($("#password").prop("type","text"),$("#psh").find("i").removeClass("icon-eye-close").addClass("icon-eye-open")):($("#password").prop("type","password"),$("#psh").find("i").removeClass("icon-eye-open").addClass("icon-eye-close"))})});
			
$(window).load(function(){$("#login .tab-box a").each(function(){$(this).click(function(){return tabeId=$(this).attr("id"),login_by=$(this).attr("rel"),$("#login_byd").val(login_by),$("#login .tab-box a").removeClass("activeLink"),$(this).addClass("activeLink"),$("#login .tabcontent").addClass("hide"),$("#"+tabeId+"-1").removeClass("hide"),!1})})});

	$(window).load(function(){
	if($(".bxslider").length){
		$(".bxslider").bxSlider({auto:!0,controls:!1,stopAutoOnClick:!0,pager:!0,slideWidth:980});
	}
	});
	</script>
<script>
$('.user_rating').click(function(){	
	var rate_val = $(this).attr('rel');
	var rate_url = '/search.php';
	var ajx_url = 'https://www.exportersindia.com/search.php';	
	var catg_1 = '';
	$.ajax({		
		url: ajx_url,	
		type: "GET",
		data: { rate_val : rate_val, rate_url : rate_url, action_type : "page_rating", catg1 : catg_1 },						
		success: function(msg) {			
			data_arr = msg.split('#####');			
			if($.trim(data_arr['0']) == 'thanks') {				
				$('#rate_val_thanks').text('Thank You for rating this Page!');
				$('#rate_val').html($.trim(data_arr['1']));	
			}
			else if($.trim(data_arr['0']) == 'rated') {
				
				$('#rate_val_thanks').text('You already rated this Page!');
			}
	  }
	  
	});
});
</script>
<script>
$(window).scroll(function() {	
	if ($(this).scrollTop() > 180) {
        $('#Post_Your_Requirement').addClass('Post_Your_Requirement_fixer');
    } else {
        $('#Post_Your_Requirement').removeClass('Post_Your_Requirement_fixer');
    }    
    if ($(this).scrollTop() > 600) {
        $('#attract_more_buyers').addClass('attract_more_buyers_fixer');
    } else {
        $('#attract_more_buyers').removeClass('attract_more_buyers_fixer');
    }
})
</script>
<script>
$(function() {
	
	$(document).on('click', '.also_dealin', function() {
		
		var cat_id = $(this).attr('link-cat-data');
		var supp_id = $(this).attr('link-mi');
		$.ajax({		
			url: 'https://www.exportersindia.com/dealin_popup_form.php',	
			type: "POST",
			data: { action_id:'show_also_dealin', catg_id: cat_id, supp_id: supp_id, s_mode: 'D'},		
			success: function(msg) {			
			$('#post_req_popup_ei').html(msg);
			}

		});
			});
});
$(document).on('click', '.join_now_click_cls', function(){
		
	if($(this).attr('attr-source-id')){
	
		var source_id = $(this).attr('attr-source-id');
		
		$.ajax({		
			url: 'https://www.exportersindia.com/ajax.php',	
			type: "POST",
			data: { action_id:'join_now_click_track', track_type:1, source_id:source_id},		
			success: function(msg) {			
			
			},
			xhrFields: {			
				withCredentials: true
			},
			crossDomain: true
		});
	}
});
</script>
<script>
$(function() { 
	$(document).on('click', '.view_mobile, .view_mobile_cls', function(){
		var url = '';
		var event_url = '';
		if($(this).attr('data-id') && $(this).attr('data-id') == '1'){
			
			var data_qstr = $(this).attr('data-qstr');
			var  data_durl = $(this).attr('data-durl');
			var data_qpg = $(this).attr('data-qpg');
			
			if(data_qstr){	
				url = $('#base_url').val()+ '/view_free_member_mobile.php?'+data_qstr;
			}
			if(data_durl){
				event_url = $('#base_url').val()+'/'+data_durl+'/'+data_qpg;
			}
			if(url && event_url){
				
				ViewMobileNumber(url, event_url);
			}
		}
	});
});
</script>	 
<script>
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) != -1) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
</script>

<script src="https://static.exportersindia.com/js/root-js/popup_ei.js"></script>
<script src="https://static.exportersindia.com/js/root-js/ei_inq_form.js"></script><!-new change 6.1.2016-->

	<script language="javascript">
	function AutoPopupForm() {
		
		open_popup_post_req_form("");
	}
	</script>
	<script language="javascript">
	var cokkie_arr = document.cookie.split('; ');
	var cookie_res = '';
	var kword_cookie_val = "";
	
	var php_serach_kword = "";

	for(var i=0;i<cokkie_arr.length;i++) {
		
		cookie_res = cokkie_arr[i].split('=');
		if(cookie_res[0]=='my_cookie_inq_keyword_val') {
			
			kword_cookie_val = decodeURIComponent(cookie_res[1]);
			break;
		}
	}
	
	var currentTime = new Date();
	
	if(kword_cookie_val=='') {
		
		/*var callAftertime = 1000*10;*/
		
		/*comment done on 13-05-15 instru by brijesh sir.abhay */
		
		var callAftertime = 1000*60*3;
	}
	else {
		
		var callAftertime = 1000*60*3;
	}
	
	if(kword_cookie_val!=php_serach_kword) { 
	
		if(document.domain=='192.168.1.104') {
		
			Set_Cookie('my_cookie_inq_keyword_val',php_serach_kword, 1, '/', '', '');
		}
		else {
		
			Set_Cookie('my_cookie_inq_keyword_val',php_serach_kword, 1, '/', '.exportersindia.com', '');
		}			
		//setTimeout("AutoPopupForm()",callAftertime);
	}
	</script>
	<!--js called below for right side form-->
<script language="javascript" src="https://static.exportersindia.com/js/root-js/inquiry_validate_form.js" type="text/javascript"></script>
<script>
inquiry_validate_form('#right-side-post-requirement-form');
</script>
<!--end block js called below for right side form-->
<script>
 
$(document).ready(function(){
	  
	if ($('.mobile_phone').length > 0) {
		$(".mobile_phone").bind('keydown',function (e) {
			 
			// Allow : backspace, delete, tab, escape, enter and .
			if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
				 // Allow : Ctrl+A, Command+A
				(e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
				 // Allow : home, end, left, right, down, up
				(e.keyCode >= 35 && e.keyCode <= 40)) {
					 // let it happen, don't do anything
					 return;
			}
			// Ensure that it is a number and stop the keypress
			if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
				e.preventDefault();
			}
		}).intlTelInput({ 
		   initialCountry : ""
		});		
	}
	
	$(document).on('click', '.post_requirement_form_li .country-list li', function(){
		var form_id = $(this).closest("form").attr('id');
		var code = $(this).attr("data-dial-code");
		flag_change(code, form_id);		
	});	
	
			$(document).on('focus', '.post_requirement_form_li .mobile_phone', function(){
			var form_id = $(this).closest("form").attr('id');
			var dial_code = $(this).parents('li').find('.country-list li.active').data("dial-code");
			var country_code = $(this).parents('li').find('.country-list li.active').data("country-code");
			if(dial_code && country_code){
				var set_country_code = country_code.toUpperCase()+'^'+dial_code;
				$('#'+form_id+' #country_code').val(set_country_code);
			}
			flag_change(dial_code, form_id);		
		});
			
});
	 	
function flag_change(code, form_id){
	
	$(".post_email").val("");
	$( ".err_mobile_phone" ).html("");
	$( ".err_user_name" ).html("");			
	if(code !=''){
		if(code==91){
			if(form_id){
				$("#div_email_"+form_id).hide();
			}
			$("#"+form_id+" .mobile_phone").attr("maxlength","10");
		}
		else{
			if(form_id){
				$("#div_email_"+form_id).show();	
			}	
			$("#"+form_id+" .mobile_phone").attr("maxlength","15");
		}
	}
}	
</script><script>
function show_notification_html(url) {
	
	$("#notification_html").html("<li class='text-center'><img src='https://static.exportersindia.com/ei_images/loader.gif' width='20'></li>");
	//
	$.ajax({
		type: 'POST',
		url: url,
		dataType: "html",
		data: { action_id: "show_notification_html"},
		cache : false,
		success: function(data) {
			//alert(data);
			$("#notification_html").html(data);
		},
		xhrFields: {			
			withCredentials: true
		},
		crossDomain: true
	});
} 

function show_member_mobile(url,country,cat) {
	$( ".notification-dropdown" ).hide();
	if (!$.trim($('.u_num').text())) {
		$("#mobile_html").html("<li class='text-center'><img src='https://static.exportersindia.com/ei_images/loader.gif' width='20'></li>");
		//
		$.ajax({
			type: 'POST',
			url: url,
			dataType: "html",
			data: { action: "show_member_mobile",type: "member",country:country,cat:cat},
			cache : false,
			success: function(data) {
				$("#mobile_html").html(data);
			},
			xhrFields: {			
				withCredentials: true
			},
			crossDomain: true
		});
	}
} 
//$('.notification').addClass('notification_top');
//$(".notification-dropdown").animate({top:'55px',height:'toggle'});
$('.notification').on('click',function() {
	$(".notification-dropdown").animate({top:'0px',height:'toggle'});
});
$(".close_me_icon").on('click',function() {
	$(".notification-dropdown").animate({top:'0px',height:'toggle'});
});

function catg_search_new (chk2, pathTy) {
	
	var str='';
	
	if(document.getElementById("search-select-hidden").value=='buy_offers') {
		
		document.getElementById("search_country_id").value = "";
	}
	
	if (chktrim(chk2.term.value).length <3 || chktrim(chk2.term.value)=="Enter Keywords here . . ." || chktrim(chk2.term.value)=="Enter keyword to search" || chktrim(chk2.term.value)=="Please enter keywords") {
		alert("Enter Product / Service Keyword(s) at least three characters");
      	//chk2.term.focus();
		chk2.term.value="";
	  	return false;
   	} 
	
	
}

function catg_search_buyer_page (chk2) {
	
	var str='';
	
	if (chktrim(chk2.term.value).length <3 || chktrim(chk2.term.value)=="Enter Keywords here . . ." || chktrim(chk2.term.value)=="Enter keyword to search" || chktrim(chk2.term.value)=="Please enter keywords") {
		alert("Enter Product / Service Keyword(s) at least three characters");
		chk2.term.value="";
	  	return false;
   	} 
	
	
}

    var search_key='';
	header_autosearch(search_key);
	
	function header_autosearch(term){
		$.ajax({
			dataType: "html",
			url: "https://www.exportersindia.com/catg_search.php",
			type: "GET",
			data: { action:'new_main_serch_kword', term: term},				
			success: function(result) {			   
				$( "#newKeywordList" ).html(result);	
						
			}	
		});
	}

	$(document).on('click', '.eih-input-dropdown li', function(){
		$('#transcript').val($(this).find('.val').text());
		$('#newKeywordList').hide();
		$( "#search-form" ).submit();
	});
	
	$(window).load(function() {
		$('.eih-searh .hst').on('click', function(){
			$('.eih-searh-overlay').show();
			$('.eih-input-dropdown').slideUp();		
			
			$('#allowed_page_popup_form').val('1');	
			if($(".notification-dropdown").length && $(".notification-dropdown").css('display') == 'block'){
				$(".notification-dropdown").animate({top:'0px',height:'toggle'});
			}
		});
		$('#transcript').on('click',function(){
			$('.eih-searh-overlay').show();
			$('.eih-input-dropdown').slideDown();
			$('.ein-header .hst-list').slideUp();
			
			$('#allowed_page_popup_form').val('1');	
		
			if($(".notification-dropdown").length && $(".notification-dropdown").css('display') == 'block'){
				$(".notification-dropdown").animate({top:'0px',height:'toggle'});
			}
		});
		$('#transcript').on('click',function(e){
			e.stopPropagation();
		})
		$("#transcript").on("keyup", function() {
			var searchText = $(this).val().toLowerCase(); 
			header_autosearch(searchText);
		});			
		$(document).on('click', '.eih-searh-overlay, .eih-header', function(){
			$('.eih-searh-overlay').hide();
			$('.eih-input-dropdown,.hst-list').slideUp();
			
			$('#allowed_page_popup_form').val('0');	
		});	
	
	});
	
	if($('.prf_li_banner').length){
	
		$(document).ready(function() {
			$('.prf_li_banner').each(function(index) {
				
				var appen_id = $(this).attr('id');
				var split_arr = appen_id.split('prf_li_banner_');
				var post_req_form_postion = split_arr[1];
				
				$.ajax({		
					url: 'https://www.exportersindia.com/ajax.php',	
					type: "POST",
					data: { action_id:'get_post_req_l3_banner', "prf_postion":post_req_form_postion},		
					success: function(msg) {			
						
						if(msg){
							
							$('#'+appen_id).after(msg);
						}
					},
					xhrFields: {			
						withCredentials: true
					},
					crossDomain: true
				});
		
			});
		});
	}
</script>
<link rel="stylesheet" type="text/css" href="https://static.exportersindia.com/css/jquery.bxslider.css">
	
	<link rel="preload" as="style" href="https://css.exportersindia.com/css/sound_search.css?v=1">
	<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://css.exportersindia.com/css/sound_search.css?v=1">
	<noscript><link rel="stylesheet" href="https://css.exportersindia.com/css/sound_search.css?v=1"></noscript>
		<link rel="preload" as="style" href="https://css.exportersindia.com/css/root-css/popup_ei.css">
	<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://css.exportersindia.com/css/root-css/popup_ei.css">
	<noscript><link rel="stylesheet" href="https://css.exportersindia.com/css/root-css/popup_ei.css"></noscript>
		<link rel="stylesheet"  href="https://css.exportersindia.com/css/footer_inner_new.css"/>
	<link rel="preload" href="https://static.exportersindia.com/fonts/fontawesome-webfont.woff" as="font" type="font/woff" crossorigin="anonymous">
<link rel="preload" href="https://static.exportersindia.com/fonts/fontawesome-webfont.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" as="style" href="https://css.exportersindia.com/css/font-awesome.min.css">
<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://css.exportersindia.com/css/font-awesome.min.css">
<noscript><link rel="stylesheet" href="https://css.exportersindia.com/css/font-awesome.min.css" crossorigin="anonymous"></noscript>

<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&family=Roboto+Condensed:wght@300;400&family=Roboto:wght@300;400;500;700&display=swap" crossorigin="anonymous">
<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&family=Roboto+Condensed:wght@300;400&family=Roboto:wght@300;400;500;700&display=swap" crossorigin="anonymous">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&family=Roboto+Condensed:wght@300;400&family=Roboto:wght@300;400;500;700&display=swap" crossorigin="anonymous"></noscript>
</body>
</html>
<script>
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) != -1) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
</script>

<script src="https://static.exportersindia.com/js/root-js/popup_ei.js"></script>
<script src="https://static.exportersindia.com/js/root-js/ei_inq_form.js"></script><!-new change 6.1.2016-->

	<script language="javascript">
	function AutoPopupForm() {
		
		open_popup_post_req_form("");
	}
	</script>
	<script language="javascript">
	var cokkie_arr = document.cookie.split('; ');
	var cookie_res = '';
	var kword_cookie_val = "";
	
	var php_serach_kword = "";

	for(var i=0;i<cokkie_arr.length;i++) {
		
		cookie_res = cokkie_arr[i].split('=');
		if(cookie_res[0]=='my_cookie_inq_keyword_val') {
			
			kword_cookie_val = decodeURIComponent(cookie_res[1]);
			break;
		}
	}
	
	var currentTime = new Date();
	
	if(kword_cookie_val=='') {
		
		/*var callAftertime = 1000*10;*/
		
		/*comment done on 13-05-15 instru by brijesh sir.abhay */
		
		var callAftertime = 1000*60*3;
	}
	else {
		
		var callAftertime = 1000*60*3;
	}
	
	if(kword_cookie_val!=php_serach_kword) { 
	
		if(document.domain=='192.168.1.104') {
		
			Set_Cookie('my_cookie_inq_keyword_val',php_serach_kword, 1, '/', '', '');
		}
		else {
		
			Set_Cookie('my_cookie_inq_keyword_val',php_serach_kword, 1, '/', '.exportersindia.com', '');
		}			
		//setTimeout("AutoPopupForm()",callAftertime);
	}
	</script>
	<!--js called below for right side form-->
<script language="javascript" src="https://static.exportersindia.com/js/root-js/inquiry_validate_form.js" type="text/javascript"></script>
<script>
inquiry_validate_form('#right-side-post-requirement-form');
</script>
<!--end block js called below for right side form-->
	<script>
	
	$(".time-save").hide();
	
	ValidateRequirementForm('#post-requirement');

	</script>  
	