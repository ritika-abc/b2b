
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Post Buy Requirement - Submit Your Buying or Selling Requirement at ExportersIndia</title>
<meta name="description" content="Feel free and submit your requirements of products/services - Post your business requirement here and get incredibly profitable responses, buy and sell products,submit your required business services. Post your requirement in the given below form, you can easily submit buy and sell for all kind of products." />
<meta name="keywords" content="post your requirement,submit your buying or selling Requirement,free fill out your requirements,post your business requirement,fulfil your requirement,submit your required business services,post your requirement at exportersindia,tell suppliers what you want,fill product your requirements" />

	<link rel="dns-prefetch" href="//static.exportersindia.com">
	<link rel="dns-prefetch" href="//dyimg.exportersindia.com">
	<link rel="dns-prefetch" href="//img1.exportersindia.com">
	<link rel="dns-prefetch" href="//img2.exportersindia.com">
	<link rel="dns-prefetch" href="//img3.exportersindia.com">
	<link rel="dns-prefetch" href="//www.google-analytics.com">
	<link rel="dns-prefetch" href="//pagead2.googlesyndication.com">
	<link rel="dns-prefetch" href="//cdn.pagesense.io">
	<link rel="dns-prefetch" href="//googleads.g.doubleclick.net">
	<link rel="dns-prefetch" href="//www.googletagmanager.com">
	<link rel="dns-prefetch" href="//connect.facebook.net">	
	<link rel="dns-prefetch" href="//static.zohocdn.com">
	<link rel="dns-prefetch" href="//www.googleadservices.com">
	<link rel="preconnect" href="//static.exportersindia.com">
	<link rel="preconnect" href="//dyimg.exportersindia.com">
	<link rel="preconnect" href="//img1.exportersindia.com">
	<link rel="preconnect" href="//img2.exportersindia.com">
	<link rel="preconnect" href="//img3.exportersindia.com">
	<link rel="preconnect" href="//www.google-analytics.com">
	<link rel="preconnect" href="//pagead2.googlesyndication.com">
	<link rel="preconnect" href="//cdn.pagesense.io">	
	<link rel="preconnect" href="//www.googletagmanager.com">
	<link rel="preconnect" href="//connect.facebook.net">
	<link rel="preconnect" href="//googleads.g.doubleclick.net">
	<link rel="preconnect" href="//static.zohocdn.com">
	<link rel="preconnect" href="//www.googleadservices.com">
	
<link rel="canonical" href="https://www.exportersindia.com/signin.htm">
<link href="https://static.exportersindia.com/css/dynamic_header_index_css.css" rel="stylesheet" type="text/css">
<script src="https://static.exportersindia.com/js/modernizr.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css"/>
<style type="text/css">
#ajax_listOfOptions{
	position:absolute;
	width:249px;
	max-height:250px;
	overflow:auto;
	border:1px solid #96b3e0;
	background:#f8fcff;
	z-index:100;
}
#ajax_listOfOptions div{
	padding:2px 5px;
	cursor: pointer;
	text-transform:capitalize;
	font-family:tahoma;
	border-bottom:1px solid #96b3e0;
}
#ajax_listOfOptions .optionDivSelected{
	background-color:#06c;
	color:#FFF;
	padding-left:10px;
}
#ajax_listOfOptions_iframe{
	background-color:#F00;
	position:absolute;
	z-index:5;
}
</style>
	
	<link rel="preload" as="style" href="https://css.exportersindia.com/css/sound_search.css?v=1">
	<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://css.exportersindia.com/css/sound_search.css?v=1">
	<noscript><link rel="stylesheet" href="https://css.exportersindia.com/css/sound_search.css?v=1"></noscript>
	
<!-- Global site tag (gtag.js) - Google Ads: 980117963 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-980117963"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', 'AW-980117963');
</script>

</head>

<body>

<aside class="no-js" style="padding-bottom:50px;">
<div class="pf w100 db darkbgerror white darkbg gbiwb tac pt5px pb5px small bdrb bdr666 b" style="z-index:999;">
<p>JavaScript is disabled in your browser. Enable JavaScript for full functionality of this site.</p>
<p>To know how to enable JavaScript in your web browser <a href="http://www.enable-javascript.com/" class="yellow" target="_blank" rel="nofollow">click here</a>.</p>
</div>
</aside>
	<div class="pf w200px" id="zopim" style="background:url(https://static.exportersindia.com/ei_images/zopim_chat.png);right:0;z-index:100;bottom:0;max-height:122px;display:none;">
	<div class="pa w100 tar white" style="bottom:10px;"><a href="javascript:void(0);" class="dib p2px5px darkbg1 br3px" onClick="$('#zopim').fadeOut(100);setMyVar('Y');">Yes</a> <a href="javascript:void(0);" class="dib p2px5px darkbg1 br3px mr2px" onClick="$('#zopim').fadeOut(100);setMyVar('N');">No</a></div>
	</div>
	

<!-- InstanceBeginEditable name="Body" -->
<header class="pr-header ffp">
	<div class="fw">
		<div class="prh-inner">
			<div>
				<a href="https://www.exportersindia.com/" class="db"><img src="https://static.exportersindia.com/ei_images/ei-logo.png" alt="ExportersIndia.Com" width="265" height="56"> </a>
			</div>
			<ul class="prh-right">
								<li>Sales : <a href="tel:+91-9953717914">+91-9953717914</a></li>
					<li>Support : <a href="tel:+91-9700318318">+91-9700318318</a></li>
								
										<li class="nam">Not a Member? <a href="https://www.exportersindia.com/register-business-online?joinfree=pyrregnow" class="join_now_click_cls" attr-source-id="5" >Register Now</a></li>						
									</ul>
		</div>	
	</div>
</header>	<style> 
	.intl-tel-input input.selected-contID{width:65px !important;}
	.intl-tel-input input[type=tel]{width: calc(100% - 118px) !important;padding:10px !important;left:auto !important}
	.ui-autocomplete{z-index:16 !important;}
	</style>

	<script src="https://static.exportersindia.com/js/latest.js/jquery.js"></script>
<script src="https://cdn.pagesense.io/js/exportersindia/ecb2ae4c4be646ea86077a3cab9c4400.js" defer></script>
		
	<script src="https://static.exportersindia.com/js/jquery.ei.js"></script>

	<script src="https://static.exportersindia.com/js/root-js/intlTelInput.js" type="text/javascript"></script>
	<script type="text/javascript" src="https://static.exportersindia.com/js/validations_func.js"></script>
	<link href="https://static.exportersindia.com/css/root-css/intlTelInput.css" rel="stylesheet" type="text/css">
	<script src="https://static.exportersindia.com/js/dynamic_attribute.js" type="text/javascript"></script>	
	<link href="https://static.exportersindia.com/css/dynamic_attribute.css" rel="stylesheet" media="all" />
	<script src="https://static.exportersindia.com/js/root-js/popup_ei.js"></script>
	<script>
	function Set_Cookie( name, value, expires, path, domain, secure ) {
		var today = new Date();
		today.setTime( today.getTime() );
			
		if ( expires ) {
							
			expires = expires * 1000 * 60 * 45;
		}
		var expires_date = new Date( today.getTime() + (expires) );
		
		document.cookie = name + "=" +escape( value ) +
		( ( expires ) ? ";expires=" + expires_date.toGMTString() : "" ) +
		( ( path ) ? ";path=" + path : "" ) +
		( ( domain ) ? ";domain=" + domain : "" ) +
		( ( secure ) ? ";secure" : "" );
	}
	</script>	
	
	<!-- for suggesion -->
	<script src="https://static.exportersindia.com/js/latest.js/jqueryui/jquery.ui.js"></script>
	<link href="https://static.exportersindia.com/css/jquery.ui.css" rel="stylesheet" type="text/css">
	<!-- for suggesion ended-->

	<style> 
	.login-label{display:block;font-size:13px;color:#333;margin-bottom:5px;font-weight:500;}
	.phone-ig{display:flex;background:#f7f7f7;border:1px solid #ccc;}
	.phone-ig .select_label_2{display:inline-block;}
	.phone-ig .select_label_2 button{border:none; padding:0; background:#f7f7f7;box-shadow:none;font-size:14px;display:flex;align-items:center;border-radius:0; position:relative;}
	.phone-ig .select_label_2 button .flag-img{order:1; line-height:0;padding:10px 22px 10px 10px; height:36px;display:flex;align-items:center;justify-content:center;box-sizing:border-box;}
	.phone-ig .select_label_2 button .isd-code{order:2;padding:10px 15px; border-left:1px solid #ddd;border-right:1px solid #ddd;color:#999;height:36px;box-sizing:border-box;}
	.phone-ig .select_label_2 button .iti-arrow{width:0;height:0;border-left:3px solid transparent;border-right:3px solid transparent;border-top:4px solid #555; position:absolute;top:18px;left:38px;}
	.phone-ig div.flag_dg{color:#333;position:absolute;border-radius:0;max-height:160px;overflow:auto;width:220px;border:1px solid #ccc;box-shadow:1px 1px 4px rgba(0,0,0,.2);z-index:9;background:#fff}
	.phone-ig div.flag_dg a{display:list-item;padding:5px 10px;cursor:pointer;list-style:none;white-space:nowrap;color:#222}
	.phone-ig div.flag_dg a.selected,div.flag_dg a:hover{background:rgba(0,0,0,.05)}
	.phone-ig div.flag_dg div{padding-left:5px}
	.phone-ig div.flag_dg p{background:#fff;font-style:italic}
	.phone-ig div.flag_dg a img,.phone-ig div.flag_dg button img{margin:0 5px}
	.bothoption{padding:10px;border:none;width:calc(100% - 109px);background:#f7f7f7;outline:none;box-shadow:none;font-size:13px;}   
	::placeholder{color:#999;opacity:1;}
	:-ms-input-placeholder {color:#999;}
	::-ms-input-placeholder {color:#999;}
	.after_login{position:relative;}
	.not-me{position:absolute;top:0;right:0;color:#06c;font-size:11px;}
	.not-me i.fa{color:#999;display:inline-block;margin-right:3px;}
	.ci-heading{border-bottom:1px solid #eee;padding-bottom:2px;margin-bottom:5px;font-weight:600;font-size:14px;}
	.after_login .ci-list{font-size:13px;color:#000;margin:0px;padding:0px;list-style:none;}
	.after_login .ci-list li{padding:1px 0;}
	.after_login .ci-list li span{color:#555;margin-right:10px;display:inline-block;min-width:115px;position:relative;}
	.after_login .ci-list li span:after{content:':';position:absolute;right:0px;}
	.after_login .ci-list li:last-child{border-right:none;}
	.location-ig{display:flex;align-items:center;border:1px solid #ccc;}
	.location-ig input[type="text"]{padding:10px;width:calc(100% - 150px);box-sizing:border-box;background:#f7f7f7;outline:none;box-shadow:none;border:none;border-radius:0;}
	input.prff_input[type="text"]:focus{background:#fff;}
	.select_label button{border:none;}
	</style>
		
<section class="pr-hb ffos">
	<div class="fw">
		<div class="prhb-heading">
			<h1>Let Us know What you Need</h1>
			<p>Just complete these simple steps. Get Instant quotes from Verified Suppliers</p>
		</div>
	</div>
</section>
<section class="pr-bs ffos">
	<div class="fw">
		<div class="prbs-inner fo">			
			<div class="prbs-inner-right">
				<div class="prf-sec">
										<form action="" method="post" id="post-requirement-form" name="post-requirement-form" enctype="multipart/form-data" onsubmit="return supplier_classified_post_req_form_2022(this, 'post-requirement-form');" >
					<input type="hidden" name="baseurl" id="baseurl" value="https://www.exportersindia.com">
					<input type="hidden" name="mem_baseurl" id="mem_baseurl" value="https://members.exportersindia.com">
					<input type="hidden" name="bydefault_catg_type"  value="2" class="bydefault_catg_type">
					
					
					<div id="step_01">
						<div class="pr-form">
							<p class="prf-title">Requirement Details</p>
							<div class="prff">
								<label class="prff-lbl">Product / Service</label>
								<input type="text" class="prff-input" placeholder="Products / Services you are looking for"name="subject" id="req_global_search_kword" value="" autocomplete="off" maxlength="50" onkeyup="checkField('subject')">
							<span id="post_auto_keyword"></span>
							<span class="error_text err_subject" style="display:none;color:red;"></span>
							</div>
							<div class="prff" id="poduct_grp_id">
							
							</div>
							<div class="prff" id="order_quantity">
								<div class="prff-row">
									<div class="prff-col-half" style="padding-right:0px;width:30%">
										<label class="prff-lbl">Quantity</label>
										<input type="number" class="prff-input empty_txt_cls" style="border-right:none" autocomplete="off" name="estimate_quantity" id="estimate_quantity" value="" maxlength="8" onkeypress="return isNumberKey(event);" onkeyup="checkField('estimate_quantity')" placeholder="Quantity">
										<span class="error_text err_estimate_quantity" style="display:none;color:red;"></span>
									</div>
									<div class="prff-col-half" style="padding-left:0;width:70%"> 
										<label class="prff-lbl">&nbsp;</label>
										<div class="units">
																							<script type="text/javascript">
												$(document).ready(function(){
													jQuery('.input_fild').show();
												});
												</script>
																							<input type="text" class="prff-input quantity_unit_class " autocomplete="off" placeholder="Unit of Measurement" name="quantity_unit_txt_fld" value="" onkeyup="checkField('quantity_unit_txt_fld')" maxlength="30" id="quantity_unit_txt_fld">
											<select class="prff-input-2" onchange="if(this.value == 'Other') jQuery('.oi-input').show(); else jQuery('.oi-input').hide();checkField('quantity_unit')" name="quantity_unit" id="quantity_unit" style="display:none;">
												<option value="">Select Unit</option>
														
														<option value="Bag" >Bag</option>		
																
														<option value="Carton" >Carton</option>		
																
														<option value="Dozen" >Dozen</option>		
																
														<option value="Feet" >Feet</option>		
																
														<option value="Kilogram" >Kilogram</option>		
																
														<option value="Meter" >Meter</option>		
																
														<option value="Metric Ton" >Metric Ton</option>		
																
														<option value="Piece" >Piece</option>		
																
														<option value="Other" selected>Other</option>		
																									</select>
											<span class="error_text err_quantity_unit" style="display:block;color:red;margin-top:2px;"></span>
										</div> 
									</div>
								</div>							
							</div>
							<div class="prff dn" id="desc_req_section">
								<label class="prff-lbl">Describe your Requirement</label>
								<textarea class="prff-input empty_txt_cls" rows="2" placeholder="Enter Additional details about your requirement..." name="detail_req" maxlength="250"   onkeyup="checkField('detail_req')" ></textarea>
								<span class="error_text err_desc_requirement" style="display:none;color:red;"></span>
							</div> 
							<div class="prff">
								<label class="prff-lbl"><span id="s_pref_label">Supplier</span> Preference</label>
								<div class="prff-radio supPrefCLS"  style="display:'';" >
									<div class="prff-ri">
										<input type="radio" name="preference" id="prs1" value="Anywhere in India"  checked  onclick="display_state(1)" class="pref_radio">
										<label for="prs1">All India</label>
									</div>
									<div class="prff-ri">
										<input type="radio" name="preference" id="prs2" value="Near by" onclick="display_state(2)" class="pref_radio">
										<label for="prs2">Near Me</label>
									</div>
									<div class="prff-ri">
										<input type="radio" name="preference" id="prs3" value="Specific States" onclick="display_state(3)" class="pref_radio">
										<label for="prs3" >Specific States</label>
									</div>								
								</div>
								<div class="prff-radio supIntPrefCLS"  style="display:none;"  >
									<div class="prff-ri">
										<input type="radio" name="preference" id="prs4" value="From India"  onclick="display_state(4)" class="pref_radio">
										<label for="prs4">From India</label>
									</div>
									<div class="prff-ri">
										<input type="radio" name="preference" id="prs5" value="Anywhere in the World" onclick="display_state(5)" class="pref_radio">
										<label for="prs5">Anywhere in the World</label>
									</div>								
								</div>
								<span class="error_text err_preference" style="display:block;color:red;margin-top:2px;"></span>
								
							</div>
							
							<div class="prff multiCLS" id="multiId3" style="display:none;">
								<label class="prff-lbl">Choose Multiple States</label> <span class="error_text err_preference_state" style="display:block;color:red;margin-top:2px;"></span>
								<div class="token-item" style="border: 1px solid #ddd;">
																  <select name="preference_state[]" id="multiple_preference_state" class="token-input" multiple>
																			
										<option value="AN">Andaman & Nicobar Islands</option>
																				
										<option value="AP">Andhra Pradesh</option>
																				
										<option value="AR">Arunachal Pradesh</option>
																				
										<option value="AS">Assam</option>
																				
										<option value="BR">Bihar</option>
																				
										<option value="CH">Chandigarh</option>
																				
										<option value="CT">Chhattisgarh</option>
																				
										<option value="DN">Dadra & Nagar Haveli</option>
																				
										<option value="DL">Delhi</option>
																				
										<option value="DD">Daman & Diu</option>
																				
										<option value="GA">Goa</option>
																				
										<option value="GJ">Gujarat</option>
																				
										<option value="HR">Haryana</option>
																				
										<option value="HP">Himachal Pradesh</option>
																				
										<option value="JK">Jammu & Kashmir</option>
																				
										<option value="JH">Jharkhand</option>
																				
										<option value="KA">Karnataka</option>
																				
										<option value="KL">Kerala</option>
																				
										<option value="LH">Ladakh</option>
																				
										<option value="LD">Lakshadweep Islands</option>
																				
										<option value="MP">Madhya Pradesh</option>
																				
										<option value="MH">Maharashtra</option>
																				
										<option value="MN">Manipur</option>
																				
										<option value="ML">Meghalaya</option>
																				
										<option value="MZ">Mizoram</option>
																				
										<option value="NL">Nagaland</option>
																				
										<option value="OR">Odisha</option>
																				
										<option value="PY">Pondicherry</option>
																				
										<option value="PB">Punjab</option>
																				
										<option value="RJ">Rajasthan</option>
																				
										<option value="SK">Sikkim</option>
																				
										<option value="TN">Tamil Nadu</option>
																				
										<option value="TS">Telangana</option>
																				
										<option value="TR">Tripura</option>
																				
										<option value="UP">Uttar Pradesh</option>
																				
										<option value="UL">Uttarakhand</option>
																				
										<option value="WB">West Bengal</option>
										 
								  </select>
								  
								</div>
								
							</div>
						    
							<input type="hidden" name="post_requirment_new_form" id="post_requirment_new_form" value="Y">
							
							<div class="prff" id="loader_attribute" style="display:none;">
								<span><img src="https://static.exportersindia.com/ei_images/loader.gif"></span>
							</div>
							
															<input type="hidden" name="lgn_member_status" id="lgn_member_status" value="3" class="lgn_member_status" />
								
							<div class="" style="display:block" id="befor_login">		    
								
								 
								<div class="prff">
									<label class="prff-lbl">Mobile Number <span id="mobile_verified_tick" style="display:none;color:green"><b class="fa fa-check-circle"></b></span></label>
									<input type="hidden" name="country_code" id="country_code" value="IN^91" >
									<input class="prff-input post_mob" type="tel" name="mobile_phone" id="mobile_phone"  placeholder="Enter Mobile Number"   maxlength="10"  onkeyup="checkField('mobile_phone')" autocomplete="off">
									<span class="error_text err_mobile_phone" style="display:none;color:red;"></span>		
									
								</div>
								
								<div class="prff div_email"  style="display:none;"  >
									<label class="prff-lbl">Email ID</label>
									<input type="text" class="prff-input post_email" placeholder="Enter your Email Id" name="user_name" id="user_name" onkeyup="checkField('user_name')"autocomplete="off">
									<span class="error_text err_user_name" style="display:none;color:red;"></span>
								</div> 
								
								
								<input type="hidden" name="your_name" id="your_name"  value="" />
								<input type="hidden" name="other_city" id="other_city"  value="" />
								
							</div>
							<div class="tac">
							
								<input type="hidden" name="product_type" id="product_type"  value="2" />
								<input type="hidden" name="preference_city"  value="" />
								<input type="hidden" name="temp_state_id" id="temp_state_id">
							
								<p class="tc">I agree to all the <a href="https://www.exportersindia.com/terms-conditions.htm" target="_new">Terms of Use</a> stated by ExportersIndia.com</p>
								<button type="submit" class="pr-btn-submit">Submit Requirement</button>
								<span class="submit_post_class_div" style="display:none;"> <img src="https://static.exportersindia.com/images/loading.gif" /></span>
							</div> 
	
							<div style="display:none" id="after_login" class="after_login">
								<a href="javascript:void(0);" onclick="$('#befor_login').show();$('#after_login').hide();document.forms['post-requirement-form'].elements['lgn_member_status'].value='3';"  id="notMe" class="not-me"><i class="fa fa-user-circle-o"></i> Not Me</a>
								<div class="ci-heading">Your Contact Information</div>
								<ul class="ci-list">
								    																										</ul>
							
								<input type="hidden" name="submit_action" id="submit_action" value="post_buy_lead_form"/>
								
								<input type="hidden" name="action_type" id="action_type" value="new_post_req_form"/>
								
								<input type="hidden" name="inq_source"  value="main_post_req_new" />						
								<input type="hidden" name="post_refer" id="post_refer" value="https://www.exportersindia.com/post-buy-requirement.php">	
							</div>
						</div>
					</div>
					</form>
					
					
					
				</div> 
			</div>
			<div class="prbs-inner-left"> 
				<h2 class="prbs-heading">Buyers Advantages?</h2>
				<ul class="prba-list">
					<li>
						<div class="prba-img">
							<img src="https://static.exportersindia.com/ei_images/prba-img1.png" alt="Immediate Responses" width="41" height="50">
						</div>
						<div class="prba-info">
							Immediate Responses <span>Get Instant Feedback from Suppliers.</span>
						</div>
					</li>
					<li>
						<div class="prba-img">
							<img src="https://static.exportersindia.com/ei_images/prba-img2.png" alt="Genuine Suppliers" width="41" height="50">
						</div>
						<div class="prba-info">
							Genuine Suppliers <span>Accredited Suppliers that Meet Your Needs.</span>
						</div>
					</li>
					<li>
						<div class="prba-img">
							<img src="https://static.exportersindia.com/ei_images/prba-img3.png" alt="Multiple Choices" width="41" height="50">
						</div>
						<div class="prba-info">
							Multiple Choices <span>Get the power to choose the best!</span>
						</div>
					</li>			
				</ul> 
			</div>
		</div>
	</div>
</section>

<script src="https://static.exportersindia.com/js/root-js/post_req_supplier.js"></script>
<script>
	function closeMyReqForm() {
		window.location.reload();
	}

	function display_product_group(prod_id){
		//console.log(prod_id);
		$("#poduct_grp_id").html("<li class='text-center'><img src='https://static.exportersindia.com/ei_images/loader.gif' width='20'></li>");
		//
		$.ajax({
			type: 'POST',
			url: 'https://www.exportersindia.com/ajax_call.php',
			dataType: "html",
			data: { action: "display_product_group",prod_id: prod_id,type: ''},
			cache : false,
			success: function(data) {
				//alert(data);
				$("#poduct_grp_id").html(data);
			},
			xhrFields: {			
				withCredentials: true
			},
			crossDomain: true
		});
	}
	
	function get_product_type(prod_id){			
		
		$.ajax({
			type: 'POST',
			url: 'https://www.exportersindia.com/ajax_call.php',
			dataType: "html",
			data: { action: "get_product_type",prod_id: prod_id,type: ''},
			cache : false,
			success: function(data) {
				//alert(data);
				if(data){
					var data2 = data.trim();
					$("#product_type").val(data2);
					$(".bydefault_catg_type").val(data2);
					$('.empty_txt_cls').val('');
					if(data2 == 1){
						$("#desc_req_section").show();
						$("#order_quantity").hide();
						$('#s_pref_label').html('Service');
					}
					else {
						$("#desc_req_section").hide();
						$("#order_quantity").show();
						$('#s_pref_label').html('Supplier');
					}
					
				}
	
				//console.log(data);
			},
			xhrFields: {			
				withCredentials: true
			},
			crossDomain: true
		});
	}
	
	function set_price_unit(radio_id){
		
		var unit_attr = [];
		
		$.ajax({		
			url: 'https://www.exportersindia.com/catg_search.php',
			type: "POST",
			async: false,
			data: { action:'get_l3_unit',catgId : radio_id},		
			success: function(getdata) {			
			 
				if($.trim(getdata)){
					var getdata = jQuery.parseJSON(getdata);
					$.each(getdata, function(index, value) {
						unit_attr.push(value);
					});
				}
			}
		});	
		
		if(unit_attr && radio_id){
	
			if($('#quantity_unit_txt_fld').val() == ''){
				
				$('#quantity_unit_txt_fld').val(unit_attr[0]);
			}
		
		}
	}
	
	
	function display_state(val){
		$(".multiCLS").hide();
		if(val==3){
			$("#multiId"+val).show();
		}
	}
	function isNumberKey(evt) {

		var charCode = (evt.which) ? evt.which : event.keyCode;
		
		//allow : 47/, -45, ,44
		
		if (charCode!=46) {
			
			if (charCode > 31 && (charCode < 43 || charCode > 57)) {
				
				//alert("Enter Only Integer Numbers.");
				return false;
			}
			else {
				
				return true;
			}
		}
	}
	
	$("document").ready( function(){
	
		$( "#req_global_search_kword" ).autocomplete({
			
			source: "https://www.exportersindia.com/catg_search.php?action=get_post_serch_kword", // data should be in json format
			
			minLength: 3,
			
			appendTo: "#post_auto_keyword",
			
			select: function(event, ui) {
				if(ui.item.value !=''){									
					$( "#req_global_search_kword" ).val(ui.item.value);
					display_product_group(ui.item.id);
					get_product_type(ui.item.id);
					
					set_price_unit(ui.item.id);
				}
			}
		});
		
		
		$("#mobile_phone,#isd_code").change( function(){
		  
			return validate_mobile_first_digit("mobile_phone", $("#isd_code").val());    
		 
		});
	   
		$("#checkme").click( function(){
			var sendbtn = document.getElementById('sendNewSms');
			if(this.checked){
			   sendbtn.disabled = false;
			   $("#sendNewSms").addClass("darkbg2");
			} else {
				sendbtn.disabled = true;
				 $("#sendNewSms").removeClass("darkbg2");
			}
		}); 
				
	});		
	</script>	
	<link rel="stylesheet" href="https://static.exportersindia.com/css/wl.token-input.css"/>
	<script type="text/javascript" src="https://static.exportersindia.com/js/root-js/wl.token-input.min.js"></script> 
	<script>
	$(window).load(function() {
			
		$('.token-input').wlTokenInput({
			//ajaxUrl: 'http://192.168.1.253/iyp/bizpage/arun/select-search/user-list.php',
		});
			$('input[name=submit]').on('click', function() {
				console.log($('.main-form').serializeArray());
			});
		});
		
		
		
	$(function(){
		$(document).on('click','.token-item-temp', function(){
			$('.token-item-search').val('');
			$('.token-item-search').attr('autocomplete', 'off');
			if(!$('.token-item-search').closest('div.token-item-selected-list').next('div').children().eq(0).hasClass('av-add')){
				
				$('.token-item-search').closest('div.token-item-selected-list').next('div').prepend("<div class='p-1 av-add' style='text-align:right;'><a href='javascript:void(0);' class='done_bt b'>Done</a></div>");
			}
			
		});
		$(document).on('click','.done_bt', function(){
			$(this).parent().parent('div').hide();
			$('.err_preference_state').html('');
		});

		$(document).on('click', '.token-item-drpdwn-ul .token-list-item', function(){
			$('.token-item-search').val('');
			$('.token-item-search').focus();
			$(".err_preference_state").html('');
			if($('.token-item-drpdown-selected').length>4){
				//alert('Only 4 selection allowed !!!')
				$(".err_preference_state").html('Only 4 states allowed !');
				$(this).removeClass('active');
				$('.token-item-selected-list').find(".token-item-drpdown-selected").slice(4).remove();
				$('.token-item-drpdown-selected-more').html('+3 More ');
			}
		});
		
		
		$(document).on('change blur', '#req_global_search_kword', function(){
	
			if($(this).val().length > 0) {
	
				$.ajax({
					dataType: "json",
					url: "https://www.exportersindia.com/catg_search.php?action=get_final_product_list_add_prod_single_catg&term="+$(this).val(),
					type: "post",
					success: function(json_data) {
						if(json_data && json_data[0]){
							
							if(json_data[0].slno){
								set_price_unit(json_data[0].slno, $('#baseurl').val());
							}
						}
					}
				});
				
			} 
		});
		
	});

	$(document).ready(function() {		
		
		$("#other_city").on('keyup input',function(){
			
			var country= $("input[name=country_code]").val();			

			if(country && country == 'IN^91'){
				
				$("#other_city").autocomplete({

					source: "https://www.exportersindia.com/feedback.htm?action=get_city&country="+country,
					minLength: 1,
					
					select: function (event, ui) {
						
						var city_state_split = ui.item.value.split('(');
						$(this).val(city_state_split[0].trim());
						if(ui.item.key){
							$('#temp_state_id').val(ui.item.key);
						}
						//var citval=$.trim(city_state_split[0]);
						//$("input[name=other_city]").val(citval);							
						return false;
					}
				});
			}
		
		});
	
					ga('send', 'event', { eventCategory: 'PostRequirement', eventAction: 'PYRFormOpen', eventLabel: 'https://members.exportersindia.com/post-requirement.php'});
		
			ga('send', { 'hitType': 'pageview', 'page': '/PostRequirement/PYRFormOpen/index.htm', 'title': 'https://members.exportersindia.com/post-requirement.php' });	
		   	});	
	</script>
			<footer class="eih-footer">
			<div class="copy_right">
				<div class="fw">
					<div class="eihf">
						<div>Copyright &copy; 1997-2024 <a href="https://www.weblink.in/" target="_blank">Weblink.In Pvt. Ltd.</a> All rights reserved.</div>
						<div> <a href="https://www.exportersindia.com/privacy-policy.htm">Privacy Policy</a> - <a href="https://www.exportersindia.com/terms-conditions.htm">Terms of Use</a> </div>
					</div>
				</div>
			</div>
		</footer>
		<style>
.member_icon .grid_pa_icon{display:none !important;}
.member_ship_icon .member_icon{display:none !important;}
	.attract_more_buyers_fixer{position:fixed; top:90px; width:250px; background:#fff;}
	</style>
<div id="popup_ei"></div>	

<!--inquiry_popop_new_chang-->
<div id="post_req_popup_ei"></div>
<!--inquiry_popop_new_change_end-->

<div id="post_req_popup_ei_thanks"></div>

<div id="login_popup_container"></div>

<input type="hidden" name="base_url" id="base_url" value="https://www.exportersindia.com">
<input type="hidden" name="mem_baseurl" id="mem_baseurl" value="https://members.exportersindia.com">
<input type="hidden" id="allowed_page_popup_form" value="0">

<!-- code for post requirement auto fill if user already loged in ended -->		
<!--used in post req form ajax-->
<input type="hidden" name="default_cont_id" id="default_cont_id" value="IN">
<input type="hidden" name="default_cont_isd_code" id="default_cont_isd_code" value="91">
<!--used in post req form ajax-->
<input type="hidden" id="root_catg_slno" value="0">
<script defer src="https://js.exportersindia.com/js/root-js/login.js?v=1714287855"></script>
<script async src="https://js.exportersindia.com/js/root-js/ei_inq_form_v4.js?v=4"></script>
<script defer src="https://static.exportersindia.com/js/root-js/post_req_supplier_v2.js?time=1714287855"></script>
	<script>
	var telInputSupported = 'input' in document && document.createElement('input').type === 'tel';

    if (telInputSupported) {
		$("input[type=tel]").intlTelInput({
			initialCountry: 'in'
		});
	}	
	</script>
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
	
  ga('create', 'UA-16625285-3', 'auto');
  ga('send', 'pageview');

</script>  
<script>
$(document).ready(function(){	
	$( "#global_search_kword" ).autocomplete({		
		source: "https://www.exportersindia.com/catg_search.php?action=get_main_serch_kword", // data should be in json format	
		appendTo: "#index_global_search",			
		minLength: 3,		
		select: function(event, ui) {			
			$( "#global_search_kword" ).val(ui.item.value);	
					
				$( "#search-form" ).submit();
				    	}
	});	
});
	
var availableUnitTags = [];
$(function(){
	
	if($('.quantity_unit_class').length){
		var ajax_url = 'https://www.exportersindia.com';
		
	    $.ajax({		
			url: ajax_url+"/catg_search.php",	
			type: "POST",
			async: false,
			data: { action:'get_cache_json_unit'},		
			success: function(getdata_data) {		
				var getdata = getdata_data.trim();
				if(getdata){
				
					getdata = jQuery.parseJSON(getdata);
		            $.each(getdata, function(index, value) {
		                availableUnitTags.push(value);
		            });
		            
				}		
			}
		});
		
		$( ".quantity_unit_class" ).autocomplete({
		  source: function( request, response ) {
	        var matcher = new RegExp( "^" + $.ui.autocomplete.escapeRegex( request.term ), "i" );
	          response( $.grep( availableUnitTags, function( item ){
	              return matcher.test( item );
	          }) );
			}
		});
	}
});

$(document).ready(function(){	
	$( "#inq_search_country" ).autocomplete({		
		source: "https://members.exportersindia.com/contact-us.htm?action=getCountryAuto", // data should be in json format		
		minLength: 2,		
		select: function(event, ui) {			
			var country_name = ui.item.value;			
			//var label = ui.item.label;        	
        	get_country_code(country_name);	
    	}
	});
});

function get_country_code(country_name) {	
	$.ajax({			
		  url:"https://members.exportersindia.com/contact-us.htm?action=getCountryCode&term="+country_name, 	  	  
		  success:function(result) {			
	  		var country_result = result.replace(/\s/g,"");	  		
	  		if(country_name=='') {		  		
		  		document.getElementById('invalid_country_id').innerHTML="Please enter country";
		  		document.getElementById('invalid_country_id').style.display="";
			  	$("#inq_search_country").attr("style","border-color:#C00;");
	  		}
	  		else {	  		
		  		if(country_result!='') {			  		
			  		document.getElementById('invalid_country_id').style.display="none";
			  		$("#inq_search_country").attr("style","border-color:none;");
		  		}
		  		else {
			  		
			  		document.getElementById('invalid_country_id').innerHTML="Please enter valid country";
			  		document.getElementById('invalid_country_id').style.display="";
			  		$("#inq_search_country").attr("style","border-color:#C00;");
		  		}
	  		}	  		
	  		common_country_select_func(country_result);
		}
	});		
}
</script>

<script>
!function(i){i(function(){var e=0;setInterval(function(){var s=i("#hp-banner-points li"),d=s.length;++e==d&&(e=0),s.find("i").removeClass("dif").addClass("silver").end().find("p").removeClass("hig").addClass("dul"),i(s[e]).find("i").removeClass("silver").addClass("dif").end().find("p").removeClass("dul").addClass("hig")},1500)})}(jQuery);
</script>
<script>
function setGridView(val) {	
			Set_Cookie( 'gridViewStatus',val, 0, '/', '.exportersindia.com', '');
		}

function getGridView() {	
	var cokkie_arr = document.cookie.split('; ');
	var cookie_res = '';	
	var view_grid_cookie_ststus = "";	
	for(var i=0;i<cokkie_arr.length;i++) {		
		cookie_res = cokkie_arr[i].split('=');		
		if(cookie_res[0]=='gridViewStatus') {			
			view_grid_cookie_ststus = cookie_res[1];			
			break;
		}
	}	
	return view_grid_cookie_ststus;
}

var protocol = window.location.href.indexOf("https://")==0?"https":"http";
var prd_target_loc = protocol+'://'+$(location).attr('hostname')+$(location).attr('pathname');

$(document).ready(function () {
	$("#gridButton").click(function () {
		$("#classified_grid_wrap").removeClass("grid_view").addClass("list_view");
		$(this).addClass("bt_on");
		$("#listButton").removeClass("bt_on");
		setGridView('G');
	});
	$("#listButton").click(function () {
		$("#classified_grid_wrap").removeClass("list_view").addClass("grid_view");
		$(this).addClass("bt_on");
		$("#gridButton").removeClass("bt_on");
		setGridView('L');
	});
	var userChoosenView = getGridView();
	if(userChoosenView=='L') {		
		$('#listButton').trigger('click');
	}
	$(document).on("click", ".nocrowl", function(e) {
		//alert($(this).data('nav'));
		location.href=$(this).data('nav');
	});
	$(document).on("click", ".bizcrowl", function(e) {
		var data_biz_catg = $(this).data('biz');
		//alert(data_biz_catg);
		location.href=prd_target_loc+'?biz_catg='+data_biz_catg;
	});	
	$(document).on("click", ".cont_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		location.href=prd_target_loc+'?cont='+cont_att;		
	});	
	$(document).on("click", ".city_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		var cont_city = $(this).data('city');
		location.href=prd_target_loc+'?cont='+cont_att+'&city='+cont_city;		
	});
	$(document).on("click", ".search_cont_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		var term_att = $(this).data('term');
		location.href=prd_target_loc+'?srch_catg_ty=buy_offers&term='+term_att+'&cont='+cont_att;		
	});
	$(document).on("click", ".state_crowl", function(e) {	
		var cont_att = $(this).data('cont');		
		var cont_state = $(this).data('state');
		var term_att = $(this).data('term');
		location.href=prd_target_loc+'?srch_catg_ty=buy_offers&term='+term_att+'&cont='+cont_att+'&state='+cont_state;		
	});
	$(document).on("click", ".search_city_crowl", function(e) {	
		var cont_att = $(this).data('cont');
		var cont_city = $(this).data('city');
		var cont_state = $(this).data('state');
		var term_att = $(this).data('term');
		location.href=prd_target_loc+'?srch_catg_ty=buy_offers&term='+term_att+'&cont='+cont_att+'&state='+cont_state+'&city='+cont_city;		
	});
});
$(".grid_fl").hover(
  function () {
    $(this).addClass("member_icon");
  },
  function () {
    $(this).removeClass("member_icon");
  }
);
$(".classified").hover(
  function () {
    $(this).addClass("member_ship_icon");
  },
  function () {
    $(this).removeClass("member_ship_icon");
  }
);
</script>
<script>
$(window).scroll(function() {    
	var topPos = $(this).scrollTop();    
	if (topPos > 100) {
		$('.to-top').fadeIn();
	} else {
		$('.to-top').fadeOut();
	}
}); 
$(document).ready(function() {
	$('.hst').on('click', function(e) {
		$('.hst-list').show();
		e.stopPropagation();
	});
	$('.hst-list li').on('click', function(e) {
		//$('.hst-txt').text($(this).text());
		//$('.hst-list').hide();
		$('.hst-txt').text($(this).text());
		var id_val = $(this).attr( "id" );
        $('.hst-list').hide();
		$('#search-select-hidden').val(id_val);
		if(id_val=='comp'){
			$('#transcript').attr("placeholder", "Enter company name to search"); //global_search_kword
		}else{
			$('#transcript').attr("placeholder", "Enter product / service to search"); //global_search_kword
		}
		e.stopPropagation();
	})
	$('html').on('click', function() {
		$('.hst-list').hide();
	})
});
$(".to-top").click(function() {
 $("html, body").animate({ scrollTop: 0 }, "slow");
 return false;
}); 
</script>
<script> 
$(document).ready(function(){$("#psh").click(function(){"password"==$("#password").prop("type")?($("#password").prop("type","text"),$("#psh").find("i").removeClass("icon-eye-close").addClass("icon-eye-open")):($("#password").prop("type","password"),$("#psh").find("i").removeClass("icon-eye-open").addClass("icon-eye-close"))})});
			
$(window).load(function(){$("#login .tab-box a").each(function(){$(this).click(function(){return tabeId=$(this).attr("id"),login_by=$(this).attr("rel"),$("#login_byd").val(login_by),$("#login .tab-box a").removeClass("activeLink"),$(this).addClass("activeLink"),$("#login .tabcontent").addClass("hide"),$("#"+tabeId+"-1").removeClass("hide"),!1})})});

</script>
<script>
$('.user_rating').click(function(){	
	var rate_val = $(this).attr('rel');
	var rate_url = '/post-buy-requirement.php';
	var ajx_url = 'https://www.exportersindia.com/post-buy-requirement.php';	
	var catg_1 = '';
	$.ajax({		
		url: ajx_url,	
		type: "GET",
		data: { rate_val : rate_val, rate_url : rate_url, action_type : "page_rating", catg1 : catg_1 },						
		success: function(msg) {			
			data_arr = msg.split('#####');			
			if($.trim(data_arr['0']) == 'thanks') {				
				$('#rate_val_thanks').text('Thank You for rating this Page!');
				$('#rate_val').html($.trim(data_arr['1']));	
			}
			else if($.trim(data_arr['0']) == 'rated') {
				
				$('#rate_val_thanks').text('You already rated this Page!');
			}
	  }
	  
	});
});
</script>
<script>
$(window).scroll(function() {	
	if ($(this).scrollTop() > 180) {
        $('#Post_Your_Requirement').addClass('Post_Your_Requirement_fixer');
    } else {
        $('#Post_Your_Requirement').removeClass('Post_Your_Requirement_fixer');
    }    
    if ($(this).scrollTop() > 600) {
        $('#attract_more_buyers').addClass('attract_more_buyers_fixer');
    } else {
        $('#attract_more_buyers').removeClass('attract_more_buyers_fixer');
    }
})
</script>
<script>
$(function() {
	
	$(document).on('click', '.also_dealin', function() {
		
		var cat_id = $(this).attr('link-cat-data');
		var supp_id = $(this).attr('link-mi');
		$.ajax({		
			url: 'https://www.exportersindia.com/dealin_popup_form.php',	
			type: "POST",
			data: { action_id:'show_also_dealin', catg_id: cat_id, supp_id: supp_id, s_mode: 'D'},		
			success: function(msg) {			
			$('#post_req_popup_ei').html(msg);
			}

		});
			});
});
$(document).on('click', '.join_now_click_cls', function(){
		
	if($(this).attr('attr-source-id')){
	
		var source_id = $(this).attr('attr-source-id');
		
		$.ajax({		
			url: 'https://www.exportersindia.com/ajax.php',	
			type: "POST",
			data: { action_id:'join_now_click_track', track_type:1, source_id:source_id},		
			success: function(msg) {			
			
			},
			xhrFields: {			
				withCredentials: true
			},
			crossDomain: true
		});
	}
});
</script>
<script>
$(function() { 
	$(document).on('click', '.view_mobile, .view_mobile_cls', function(){
		var url = '';
		var event_url = '';
		if($(this).attr('data-id') && $(this).attr('data-id') == '1'){
			
			var data_qstr = $(this).attr('data-qstr');
			var  data_durl = $(this).attr('data-durl');
			var data_qpg = $(this).attr('data-qpg');
			
			if(data_qstr){	
				url = $('#base_url').val()+ '/view_free_member_mobile.php?'+data_qstr;
			}
			if(data_durl){
				event_url = $('#base_url').val()+'/'+data_durl+'/'+data_qpg;
			}
			if(url && event_url){
				
				ViewMobileNumber(url, event_url);
			}
		}
	});
});
</script>	 
<script>
 
$(document).ready(function(){
	  
	if ($('.mobile_phone').length > 0) {
		$(".mobile_phone").bind('keydown',function (e) {
			 
			// Allow : backspace, delete, tab, escape, enter and .
			if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
				 // Allow : Ctrl+A, Command+A
				(e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
				 // Allow : home, end, left, right, down, up
				(e.keyCode >= 35 && e.keyCode <= 40)) {
					 // let it happen, don't do anything
					 return;
			}
			// Ensure that it is a number and stop the keypress
			if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
				e.preventDefault();
			}
		}).intlTelInput({ 
		   initialCountry : "in"
		});		
	}
	
	$(document).on('click', '.post_requirement_form_li .country-list li', function(){
		var form_id = $(this).closest("form").attr('id');
		var code = $(this).attr("data-dial-code");
		flag_change(code, form_id);		
	});	
	
			$(document).on('focus', '.post_requirement_form_li .mobile_phone', function(){
			var form_id = $(this).closest("form").attr('id');
			var dial_code = $(this).parents('li').find('.country-list li.active').data("dial-code");
			var country_code = $(this).parents('li').find('.country-list li.active').data("country-code");
			if(dial_code && country_code){
				var set_country_code = country_code.toUpperCase()+'^'+dial_code;
				$('#'+form_id+' #country_code').val(set_country_code);
			}
			flag_change(dial_code, form_id);		
		});
			
});
	 	
function flag_change(code, form_id){
	
	$(".post_email").val("");
	$( ".err_mobile_phone" ).html("");
	$( ".err_user_name" ).html("");			
	if(code !=''){
		if(code==91){
			if(form_id){
				$("#div_email_"+form_id).hide();
			}
			$("#"+form_id+" .mobile_phone").attr("maxlength","10");
		}
		else{
			if(form_id){
				$("#div_email_"+form_id).show();	
			}	
			$("#"+form_id+" .mobile_phone").attr("maxlength","15");
		}
	}
}	
</script><script>
function show_notification_html(url) {
	
	$("#notification_html").html("<li class='text-center'><img src='https://static.exportersindia.com/ei_images/loader.gif' width='20'></li>");
	//
	$.ajax({
		type: 'POST',
		url: url,
		dataType: "html",
		data: { action_id: "show_notification_html"},
		cache : false,
		success: function(data) {
			//alert(data);
			$("#notification_html").html(data);
		},
		xhrFields: {			
			withCredentials: true
		},
		crossDomain: true
	});
} 

function show_member_mobile(url,country,cat) {
	$( ".notification-dropdown" ).hide();
	if (!$.trim($('.u_num').text())) {
		$("#mobile_html").html("<li class='text-center'><img src='https://static.exportersindia.com/ei_images/loader.gif' width='20'></li>");
		//
		$.ajax({
			type: 'POST',
			url: url,
			dataType: "html",
			data: { action: "show_member_mobile",type: "member",country:country,cat:cat},
			cache : false,
			success: function(data) {
				$("#mobile_html").html(data);
			},
			xhrFields: {			
				withCredentials: true
			},
			crossDomain: true
		});
	}
} 
//$('.notification').addClass('notification_top');
//$(".notification-dropdown").animate({top:'55px',height:'toggle'});
$('.notification').on('click',function() {
	$(".notification-dropdown").animate({top:'0px',height:'toggle'});
});
$(".close_me_icon").on('click',function() {
	$(".notification-dropdown").animate({top:'0px',height:'toggle'});
});

function catg_search_new (chk2, pathTy) {
	
	var str='';
	
	if(document.getElementById("search-select-hidden").value=='buy_offers') {
		
		document.getElementById("search_country_id").value = "";
	}
	
	if (chktrim(chk2.term.value).length <3 || chktrim(chk2.term.value)=="Enter Keywords here . . ." || chktrim(chk2.term.value)=="Enter keyword to search" || chktrim(chk2.term.value)=="Please enter keywords") {
		alert("Enter Product / Service Keyword(s) at least three characters");
      	//chk2.term.focus();
		chk2.term.value="";
	  	return false;
   	} 
	
	
}

function catg_search_buyer_page (chk2) {
	
	var str='';
	
	if (chktrim(chk2.term.value).length <3 || chktrim(chk2.term.value)=="Enter Keywords here . . ." || chktrim(chk2.term.value)=="Enter keyword to search" || chktrim(chk2.term.value)=="Please enter keywords") {
		alert("Enter Product / Service Keyword(s) at least three characters");
		chk2.term.value="";
	  	return false;
   	} 
	
	
}

    var search_key='';
	header_autosearch(search_key);
	
	function header_autosearch(term){
		$.ajax({
			dataType: "html",
			url: "https://www.exportersindia.com/catg_search.php",
			type: "GET",
			data: { action:'new_main_serch_kword', term: term},				
			success: function(result) {			   
				$( "#newKeywordList" ).html(result);	
						
			}	
		});
	}

	$(document).on('click', '.eih-input-dropdown li', function(){
		$('#transcript').val($(this).find('.val').text());
		$('#newKeywordList').hide();
		$( "#search-form" ).submit();
	});
	
	$(window).load(function() {
		$('.eih-searh .hst').on('click', function(){
			$('.eih-searh-overlay').show();
			$('.eih-input-dropdown').slideUp();		
			
			$('#allowed_page_popup_form').val('1');	
			if($(".notification-dropdown").length && $(".notification-dropdown").css('display') == 'block'){
				$(".notification-dropdown").animate({top:'0px',height:'toggle'});
			}
		});
		$('#transcript').on('click',function(){
			$('.eih-searh-overlay').show();
			$('.eih-input-dropdown').slideDown();
			$('.ein-header .hst-list').slideUp();
			
			$('#allowed_page_popup_form').val('1');	
		
			if($(".notification-dropdown").length && $(".notification-dropdown").css('display') == 'block'){
				$(".notification-dropdown").animate({top:'0px',height:'toggle'});
			}
		});
		$('#transcript').on('click',function(e){
			e.stopPropagation();
		})
		$("#transcript").on("keyup", function() {
			var searchText = $(this).val().toLowerCase(); 
			header_autosearch(searchText);
		});			
		$(document).on('click', '.eih-searh-overlay, .eih-header', function(){
			$('.eih-searh-overlay').hide();
			$('.eih-input-dropdown,.hst-list').slideUp();
			
			$('#allowed_page_popup_form').val('0');	
		});	
	
	});
	
	if($('.prf_li_banner').length){
	
		$(document).ready(function() {
			$('.prf_li_banner').each(function(index) {
				
				var appen_id = $(this).attr('id');
				var split_arr = appen_id.split('prf_li_banner_');
				var post_req_form_postion = split_arr[1];
				
				$.ajax({		
					url: 'https://www.exportersindia.com/ajax.php',	
					type: "POST",
					data: { action_id:'get_post_req_l3_banner', "prf_postion":post_req_form_postion},		
					success: function(msg) {			
						
						if(msg){
							
							$('#'+appen_id).after(msg);
						}
					},
					xhrFields: {			
						withCredentials: true
					},
					crossDomain: true
				});
		
			});
		});
	}
</script>
<link rel="stylesheet" type="text/css" href="https://static.exportersindia.com/css/jquery.bxslider.css">
	<link rel="preload" as="style" href="https://css.exportersindia.com/css/root-css/popup_ei.css">
	<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://css.exportersindia.com/css/root-css/popup_ei.css">
	<noscript><link rel="stylesheet" href="https://css.exportersindia.com/css/root-css/popup_ei.css"></noscript>
		<link rel="stylesheet"  href="https://css.exportersindia.com/css/footer_inner_new.css"/>
	<link rel="preload" href="https://static.exportersindia.com/fonts/fontawesome-webfont.woff" as="font" type="font/woff" crossorigin="anonymous">
<link rel="preload" href="https://static.exportersindia.com/fonts/fontawesome-webfont.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" as="style" href="https://css.exportersindia.com/css/font-awesome.min.css">
<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://css.exportersindia.com/css/font-awesome.min.css">
<noscript><link rel="stylesheet" href="https://css.exportersindia.com/css/font-awesome.min.css" crossorigin="anonymous"></noscript>

<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&family=Roboto+Condensed:wght@300;400&family=Roboto:wght@300;400;500;700&display=swap" crossorigin="anonymous">
<link rel="stylesheet" media="print" onload="this.onload=null;this.removeAttribute('media');" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&family=Roboto+Condensed:wght@300;400&family=Roboto:wght@300;400;500;700&display=swap" crossorigin="anonymous">
<noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700&family=Roboto+Condensed:wght@300;400&family=Roboto:wght@300;400;500;700&display=swap" crossorigin="anonymous"></noscript>
</body>
</html>
<script>
$(function(){
	$("#mobile_phone").bind('keydown',function (e) {
		// Allow : backspace, delete, tab, escape, enter and .
		if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
			 // Allow : Ctrl+A, Command+A
			(e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
			 // Allow : home, end, left, right, down, up
			(e.keyCode >= 35 && e.keyCode <= 40)) {
				 // let it happen, don't do anything
				 return;
		}
		// Ensure that it is a number and stop the keypress
		if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
			e.preventDefault();
		}
	}).intlTelInput({ 
	   initialCountry : "in"
	});		
	
	$(document).on('click', '.country-list li', function(){
		var code = $(this).attr("data-dial-code");
		flag_change(code);		
	});	
			$(document).on('keyup keydown', '#mobile_phone', function(){
			$this = $('#post-requirement-form .country-list li.active');
			var code = $this.attr("data-dial-code");
			flag_change(code);
		});
		});
		
		
		
	function flag_change(code){
		
		$(".post_email").val("");
		$( ".err_mobile_phone" ).html("");
		$( ".err_user_name" ).html("");			
		//console.log(code);			
		if(code !=''){
			if(code==91){
				$(".div_email").hide();
				$(".post_mob").attr("maxlength","10");
				$(".supIntPrefCLS").hide();
				$(".supPrefCLS").show();				
				//$(".multiCLS").show();
				$rad_val=$("input[type='radio'][name='preference']:checked").val();			
				if($rad_val =='From India' || $rad_val =='Anywhere in the World'){
					$( ".pref_radio" ).prop( "checked", false );
					$( "#prs1" ).prop( "checked", true );
					$(".multiCLS").hide();
				}
				
				
			}
			else{
				$(".div_email").show();				
				$(".post_mob").attr("maxlength","15");
				//$(".post_email").focus();
				$(".supPrefCLS").hide();
				$(".multiCLS").hide();
				$(".supIntPrefCLS").show();
				
				$rad_val=$("input[type='radio'][name='preference']:checked").val();			
				if($rad_val !='From India' && $rad_val !='Anywhere in the World'){
					$( ".pref_radio" ).prop( "checked", false );
					$( "#prs4" ).prop( "checked", true );
				}			
				//$("input:radio[name=preference]:checked")[0].checked = false;
			}
		}
	}

	
</script>

